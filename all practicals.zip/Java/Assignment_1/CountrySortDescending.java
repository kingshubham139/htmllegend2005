import java.util.Scanner;
import java.util.Arrays;
import java.util.Collections;

public class CountrySortDescending 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of countries: ");
        int n = sc.nextInt();
        sc.nextLine(); 
        String[] countries = new String[n];

        for (int i = 0; i < n; i++)
        {
            System.out.print("Enter country name " + (i + 1) + ": ");
            countries[i] = sc.nextLine();
        }

        Arrays.sort(countries, Collections.reverseOrder());

        System.out.println("\nCountries in Descending Order:");
        for (String country : countries) 
        {
            System.out.println(country);
        }

        sc.close();
    }
}
