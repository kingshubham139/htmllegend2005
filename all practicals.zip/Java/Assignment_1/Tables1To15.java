
//Write a program to display the 1 to 15 tables.

public class Tables1To15 {

    public static void main(String[] args) {

		//outer loop indicate 1 to 15 table no
        for (int i = 1; i <= 15; i++) {
            System.out.println("Table of " + i + ":"); 

            // Inner loop calculates and prints the products for the current tableNumber
            for (int j = 1; j <= 10; j++) {
                int product = i * j;
                System.out.println(i + " * " + j + " = " + product);
            }
            System.out.println(); 
        }
    }
}