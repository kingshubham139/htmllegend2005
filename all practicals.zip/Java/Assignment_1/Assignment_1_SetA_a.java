/*
Write a menu driven program to perform the following operations
i. Calculate the volume of cylinder. (hint : Volume: p × r² × h)
ii. Find the factorial of given number.
iii. Check the number is Armstrong or not.
iv. Exit 
*/


import java.util.Scanner;

public class Assignment_1_SetA_a {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n----- Menu -----");
            System.out.println("1. Calculate Volume of Cylinder");
            System.out.println("2. Find Factorial of a Number");
            System.out.println("3. Check Armstrong Number");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    // Volume = p * r^2 * h
                    System.out.print("Enter radius: ");
                    double r = sc.nextDouble();
                    System.out.print("Enter height: ");
                    double h = sc.nextDouble();
                    double volume = Math.PI * r * r * h;
                    System.out.println("Volume of Cylinder: " + volume);
                    break;

                case 2:
                    // Factorial
                    System.out.print("Enter a number: ");
                    int num = sc.nextInt();
                    int fact = 1;
                    for (int i = 1; i <= num; i++) {
                        fact *= i;
                    }
                    System.out.println("Factorial: " + fact);
                    break;

                case 3:
                    // Armstrong check
                    System.out.print("Enter a number: ");
                    int n = sc.nextInt();
                    int temp = n, rem, sum = 0;
                    while (temp > 0) {
                        rem = temp % 10;
                        sum += rem * rem * rem;
                        temp = temp / 10;
                    }
                    if (sum == n)
                        System.out.println(n + " is an Armstrong number.");
                    else
                        System.out.println(n + " is not an Armstrong number.");
                    break;

                case 4:
                    System.out.println("Exiting the program. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }

        } while (choice != 4);
    }
}
