/* 
Define a class MyNumber having one private int data member. Write a default
constructor to initialize it to 0 and another constructor to initialize it to a value
(Use this). Write methods isNegative, isPositive, isZero, isOdd, isEven. Create an
object in main. Use command line arguments to pass a value to the object
(Hint : convert string argument to integer) and perform the above tests. Provide
javadoc comments for all constructors and methods and generate the html help file.
*/

public class MyNumber {
    private int num;

    public MyNumber() {
        this.num = 0;
    }

    public MyNumber(int num) {
        this.num = num;
    }

    public boolean isNegative() {
        return num < 0;
    }

    public boolean isPositive() {
        return num > 0;
    }

    public boolean isZero() {
        return num == 0;
    }

    public boolean isOdd() {
        return num % 2 != 0;
    }

    public boolean isEven() {
        return num % 2 == 0;
    }

    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Please provide a number as command-line argument.");
            return;
        }

        int inputNum = Integer.parseInt(args[0]);
        MyNumber obj = new MyNumber(inputNum);

        System.out.println("Number: " + inputNum);
        System.out.println("Is Negative? \n" + obj.isNegative());
        System.out.println("Is Positive? \n" + obj.isPositive());
        System.out.println("Is Zero? \n" + obj.isZero());
        System.out.println("Is Odd? \n" + obj.isOdd());
        System.out.println("Is Even? \n" + obj.isEven());
    }
}
