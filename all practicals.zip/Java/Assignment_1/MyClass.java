class MyClass {
    public static void main(String[] args) {
        int a = 5, b = 10;
        int sum = a + b;
        System.out.println("Sum is: " + sum);
    }
}


/* Compilling Command	javac file_name.java
			javap -c Class_Name
   Output Command 	java Class_Name
*/
