import java.util.Scanner;

public class MatrixMenu {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[][] matrix1, matrix2, result;
        int row, col;

        while (true) {
            System.out.println("\n----- MENU -----");
            System.out.println("1. Matrix Addition");
            System.out.println("2. Matrix Multiplication");
            System.out.println("3. Transpose of a Matrix");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1: // Addition
                    System.out.print("Enter rows and columns of matrices: ");
                    row = sc.nextInt();
                    col = sc.nextInt();
                    matrix1 = new int[row][col];
                    matrix2 = new int[row][col];
                    System.out.println("Enter elements of Matrix 1:");
                    readMatrix(sc, matrix1);
                    System.out.println("Enter elements of Matrix 2:");
                    readMatrix(sc, matrix2);
                    result = addMatrix(matrix1, matrix2);
                    System.out.println("Resultant Matrix After Addition:");
                    printMatrix(result);
                    break;

                case 2: // Multiplication
                    System.out.print("Enter rows and columns of Matrix 1: ");
                    int r1 = sc.nextInt();
                    int c1 = sc.nextInt();
                    System.out.print("Enter rows and columns of Matrix 2: ");
                    int r2 = sc.nextInt();
                    int c2 = sc.nextInt();

                    if (c1 != r2) {
                        System.out.println("Multiplication not possible. Columns of M1 must equal rows of M2.");
                        break;
                    }

                    matrix1 = new int[r1][c1];
                    matrix2 = new int[r2][c2];
                    System.out.println("Enter elements of Matrix 1:");
                    readMatrix(sc, matrix1);
                    System.out.println("Enter elements of Matrix 2:");
                    readMatrix(sc, matrix2);
                    result = multiplyMatrix(matrix1, matrix2);
                    System.out.println("Resultant Matrix After Multiplication:");
                    printMatrix(result);
                    break;

                case 3: // Transpose
                    System.out.print("Enter rows and columns of the matrix: ");
                    row = sc.nextInt();
                    col = sc.nextInt();
                    matrix1 = new int[row][col];
                    System.out.println("Enter elements of Matrix:");
                    readMatrix(sc, matrix1);
                    result = transposeMatrix(matrix1);
                    System.out.println("Transpose of the Matrix:");
                    printMatrix(result);
                    break;

                case 4: // Exit
                    System.out.println("Exiting the program.");
                    return;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    // Read matrix from user
    static void readMatrix(Scanner sc, int[][] matrix) {
        for (int i = 0; i < matrix.length; i++)
            for (int j = 0; j < matrix[0].length; j++)
                matrix[i][j] = sc.nextInt();
    }

    // Print matrix
    static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int val : row)
                System.out.print(val + "\t");
            System.out.println();
        }
    }

    // Add matrices
    static int[][] addMatrix(int[][] a, int[][] b) {
        int[][] result = new int[a.length][a[0].length];
        for (int i = 0; i < a.length; i++)
            for (int j = 0; j < a[0].length; j++)
                result[i][j] = a[i][j] + b[i][j];
        return result;
    }

    // Multiply matrices
    static int[][] multiplyMatrix(int[][] a, int[][] b) {
        int[][] result = new int[a.length][b[0].length];
        for (int i = 0; i < a.length; i++)
            for (int j = 0; j < b[0].length; j++)
                for (int k = 0; k < a[0].length; k++)
                    result[i][j] += a[i][k] * b[k][j];
        return result;
    }

    // Transpose matrix
    static int[][] transposeMatrix(int[][] matrix) {
        int[][] transposed = new int[matrix[0].length][matrix.length];
        for (int i = 0; i < matrix.length; i++)
            for (int j = 0; j < matrix[0].length; j++)
                transposed[j][i] = matrix[i][j];
        return transposed;
    }
}
