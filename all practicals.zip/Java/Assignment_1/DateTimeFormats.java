/* 
Write a java program to display the system date and time in various formats shown
below:
Current date is : 31/08/2021
Current date is : 08-31-2021
Current date is : Tuesday August 31 2021
Current date and time is : Fri August 31 15:25:59 IST 2021
Current date and time is : 31/08/21 15:25:59 PM +0530
Current time is : 15:25:59
Current week of year is : 35
Current week of month : 5
Current day of the year is : 243
Note: Use java.util.Date and java.text.SimpleDateFormat class
*/


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;

public class DateTimeFormats {
    public static void main(String[] args) {
        Date now = new Date();
        Calendar cal = Calendar.getInstance();

        // Format 1: 31/08/2021
        SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
        System.out.println("Current date is : " + sdf1.format(now));

        // Format 2: 08-31-2021
        SimpleDateFormat sdf2 = new SimpleDateFormat("MM-dd-yyyy");
        System.out.println("Current date is : " + sdf2.format(now));

        // Format 3: Tuesday August 31 2021
        SimpleDateFormat sdf3 = new SimpleDateFormat("EEEE MMMM dd yyyy");
        System.out.println("Current date is : " + sdf3.format(now));

        // Format 4: Fri August 31 15:25:59 IST 2021
        SimpleDateFormat sdf4 = new SimpleDateFormat("EEE MMMM dd HH:mm:ss z yyyy");
        System.out.println("Current date and time is : " + sdf4.format(now));

        // Format 5: 31/08/21 15:25:59 PM +0530
        SimpleDateFormat sdf5 = new SimpleDateFormat("dd/MM/yy HH:mm:ss a Z");
        System.out.println("Current date and time is : " + sdf5.format(now));

        // Format 6: 15:25:59
        SimpleDateFormat sdf6 = new SimpleDateFormat("HH:mm:ss");
        System.out.println("Current time is : " + sdf6.format(now));

        // Week of year
        int weekOfYear = cal.get(Calendar.WEEK_OF_YEAR);
        System.out.println("Current week of year is : " + weekOfYear);

        // Week of month
        int weekOfMonth = cal.get(Calendar.WEEK_OF_MONTH);
        System.out.println("Current week of month : " + weekOfMonth);

        // Day of year
        int dayOfYear = cal.get(Calendar.DAY_OF_YEAR);
        System.out.println("Current day of the year is : " + dayOfYear);
    }
}
