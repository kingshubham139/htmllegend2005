
interface Operation {
    double PI = 3.142;  

    double area();      
    double volume();  
}


class Cylinder implements Operation {
    private double radius;
    private double height;


    public Cylinder(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }

   
    public double area() {
        return 2 * PI * radius * (height + radius);
    }


    public double volume() {
        return PI * radius * radius * height;
    }
}


public class CylinderTest {
    public static void main(String[] args) {
        Cylinder cyl = new Cylinder(5, 10);

        System.out.printf("Surface Area of Cylinder: %.2f%n", cyl.area());
        System.out.printf("Volume of Cylinder: %.2f%n", cyl.volume());
    }
}

