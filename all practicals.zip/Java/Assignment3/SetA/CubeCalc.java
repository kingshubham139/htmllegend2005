import java.util.Scanner;

@FunctionalInterface
interface Cube {
    int calculate(int n);
}

public class CubeCalc {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Cube cube = n -> n * n * n;

        System.out.print("Enter a number: ");
        int num = sc.nextInt();

        int result = cube.calculate(num);

        System.out.println("Cube of " + num + " is " + result);

        sc.close();
    }
}


