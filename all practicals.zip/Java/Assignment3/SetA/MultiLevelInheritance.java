
// Base class
class Continent {
    String continentName;

    Continent(String continentName) {
        this.continentName = continentName;
    }
}

// Derived class from Continent
class Country extends Continent {
    String countryName;

    Country(String continentName, String countryName) {
        super(continentName);
        this.countryName = countryName;
    }
}

// Derived class from Country
class State extends Country {
    String stateName;

    State(String continentName, String countryName, String stateName) {
        super(continentName, countryName);
        this.stateName = stateName;
    }
}

// Derived class from State
class Place extends State {
    String placeName;

    Place(String continentName, String countryName, String stateName, String placeName) {
        super(continentName, countryName, stateName);
        this.placeName = placeName;
    }

    void displayDetails() {
        System.out.println("Continent:" + continentName);
        System.out.println("Country:  " + countryName);
        System.out.println("State:    " + stateName);
        System.out.println("Place:    " + placeName);


    }
}

// Main class
public class MultiLevelInheritance{
    public static void main(String[] args) {
        Place place = new Place("Asia", "India", "Karnataka", "Bangalore");
        place.displayDetails();
    }
}

