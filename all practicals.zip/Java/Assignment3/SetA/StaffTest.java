import java.util.Scanner;


abstract class Staff {
    protected int id;
    protected String name;


    public Staff(int id, String name) {
        this.id = id;
        this.name = name;
    }


    public abstract void displayDetails();
}


class OfficeStaff extends Staff {
    private String department;

    public OfficeStaff(int id, String name, String department) {
        super(id, name);
        this.department = department;
    }


    public void displayDetails() {
        System.out.println("ID        : " + id);
        System.out.println("Name      : " + name);
        System.out.println("Department: " + department);
        System.out.println("--------------------------");
    }
}

public class StaffTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of OfficeStaff objects: ");
        int n = sc.nextInt();
        sc.nextLine();  // consume newline

        OfficeStaff[] staffArray = new OfficeStaff[n];

        // Input details
        for (int i = 0; i < n; i++) {
            System.out.println("Enter details for staff #" + (i + 1) + ":");
            System.out.print("ID: ");
            int id = sc.nextInt();
            sc.nextLine();  // consume newline
            System.out.print("Name: ");
            String name = sc.nextLine();
            System.out.print("Department: ");
            String dept = sc.nextLine();

            staffArray[i] = new OfficeStaff(id, name, dept);
            System.out.println();
        }

        // Display details
        System.out.println("Details of Office Staff:");
        System.out.println("-----------------------");
        for (OfficeStaff staff : staffArray) {
            staff.displayDetails();
        }

        sc.close();
    }
}

