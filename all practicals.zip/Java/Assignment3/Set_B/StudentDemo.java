import java.util.*;


interface Department {
    String deptName = "Computer Science";
    String deptHead = "Dr. Sharma";

    void printDepartmentDetails();
}


class Hostel {
    String hostelName;
    String hostelLocation;
    int numberOfRooms;

    Hostel(String hostelName, String hostelLocation, int numberOfRooms) {
        this.hostelName = hostelName;
        this.hostelLocation = hostelLocation;
        this.numberOfRooms = numberOfRooms;
    }

    void printHostelDetails() {
        System.out.println("Hostel Name: " + hostelName);
        System.out.println("Hostel Location: " + hostelLocation);
        System.out.println("Number of Rooms: " + numberOfRooms);
    }
}


class Student extends Hostel implements Department {
    String studentName;
    String regNo;
    String electiveSubject;
    double avgMarks;

    Student(String hostelName, String hostelLocation, int numberOfRooms,
            String studentName, String regNo, String electiveSubject, double avgMarks) {
        super(hostelName, hostelLocation, numberOfRooms);
        this.studentName = studentName;
        this.regNo = regNo;
        this.electiveSubject = electiveSubject;
        this.avgMarks = avgMarks;
    }

    void printData() {
        System.out.println("Student Name: " + studentName);
        System.out.println("Reg No: " + regNo);
        System.out.println("Elective Subject: " + electiveSubject);
        System.out.println("Average Marks: " + avgMarks);
        printHostelDetails();
        printDepartmentDetails();
    }

    @Override
    public void printDepartmentDetails() {
        System.out.println("Department Name: " + deptName);
        System.out.println("Department Head: " + deptHead);
    }
}


public class StudentDemo {
    static Scanner sc = new Scanner(System.in);
    static List<Student> students = new ArrayList<>();

    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Admit new student");
            System.out.println("2. Migrate a student");
            System.out.println("3. Display details of a student");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    admitStudent();
                    break;
                case 2:
                    migrateStudent();
                    break;
                case 3:
                    displayStudent();
                    break;
                case 4:
                    System.out.println("Exiting program...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while (choice != 4);
    }

    static void admitStudent() {
        System.out.print("Enter Hostel Name: ");
        String hname = sc.nextLine();
        System.out.print("Enter Hostel Location: ");
        String hloc = sc.nextLine();
        System.out.print("Enter Number of Rooms: ");
        int rooms = sc.nextInt();
        sc.nextLine(); 

        System.out.print("Enter Student Name: ");
        String sname = sc.nextLine();
        System.out.print("Enter Reg No: ");
        String reg = sc.nextLine();
        System.out.print("Enter Elective Subject: ");
        String subj = sc.nextLine();
        System.out.print("Enter Average Marks: ");
        double marks = sc.nextDouble();
        sc.nextLine(); 

        Student s = new Student(hname, hloc, rooms, sname, reg, subj, marks);
        students.add(s);

        System.out.println("Student admitted successfully!");
    }

    static void migrateStudent() {
        System.out.print("Enter Reg No of student to migrate: ");
        String reg = sc.nextLine();

        boolean found = false;
        Iterator<Student> it = students.iterator();
        while (it.hasNext()) {
            Student s = it.next();
            if (s.regNo.equals(reg)) {
                it.remove();
                System.out.println("Student with Reg No " + reg + " migrated successfully!");
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Student not found!");
        }
    }

    static void displayStudent() {
        System.out.print("Enter Reg No of student: ");
        String reg = sc.nextLine();

        boolean found = false;
        for (Student s : students) {
            if (s.regNo.equals(reg)) {
                s.printData();
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Student not found!");
        }
    }
}

