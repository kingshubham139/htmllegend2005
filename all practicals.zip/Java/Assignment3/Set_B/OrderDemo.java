import java.util.Scanner;


abstract class Order {
    int id;
    String description;

    abstract void accept(Scanner sc);
    abstract void display();
}


class PurchaseOrder extends Order {
    String customerName;

    @Override
    void accept(Scanner sc) {
        System.out.print("Enter Purchase Order ID: ");
        id = sc.nextInt();
        sc.nextLine(); 
        System.out.print("Enter Description: ");
        description = sc.nextLine();
        System.out.print("Enter Customer Name: ");
        customerName = sc.nextLine();
    }

    @Override
    void display() {
        System.out.println("Purchase Order ID: " + id);
        System.out.println("Description: " + description);
        System.out.println("Customer Name: " + customerName);
        System.out.println("---------------------------");
    }
}

                   
class SalesOrder extends Order {
    String vendorName;

    @Override
    void accept(Scanner sc) {
        System.out.print("Enter Sales Order ID: ");
        id = sc.nextInt();
        sc.nextLine(); 
        System.out.print("Enter Description: ");
        description = sc.nextLine();
        System.out.print("Enter Vendor Name: ");
        vendorName = sc.nextLine();
    }

    @Override
    void display() {
        System.out.println("Sales Order ID: " + id);
        System.out.println("Description: " + description);
        System.out.println("Vendor Name: " + vendorName);
        System.out.println("---------------------------");
    }
}


public class OrderDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        PurchaseOrder[] po = new PurchaseOrder[3];
        SalesOrder[] so = new SalesOrder[3];

        System.out.println("\n--- Enter Details for Purchase Orders ---");
        for (int i = 0; i < 3; i++) {
            System.out.println("\nPurchase Order " + (i + 1) + ":");
            po[i] = new PurchaseOrder();
            po[i].accept(sc);
        }

        System.out.println("\n--- Enter Details for Sales Orders ---");
        for (int i = 0; i < 3; i++) {
            System.out.println("\nSales Order " + (i + 1) + ":");
            so[i] = new SalesOrder();
            so[i].accept(sc);
        }

        System.out.println("\n--- Displaying Purchase Orders ---");
        for (int i = 0; i < 3; i++) {
            po[i].display();
        }

        System.out.println("\n--- Displaying Sales Orders ---");
        for (int i = 0; i < 3; i++) {
            so[i].display();
        }

        sc.close();
    }
}

