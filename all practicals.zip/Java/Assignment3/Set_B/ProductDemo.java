
interface Marker { }


class Product implements Marker {
    int product_id;
    String product_name;
    double product_cost;
    int product_quantity;


    static int count = 0;


    Product() {
        product_id = 0;
        product_name = "Not Available";
        product_cost = 0.0;
        product_quantity = 0;
        count++; 
    }


    Product(int id, String name, double cost, int qty) {
        product_id = id;
        product_name = name;
        product_cost = cost;
        product_quantity = qty;
        count++; 
    }


    void display() {
        System.out.println("Product ID      : " + product_id);
        System.out.println("Product Name    : " + product_name);
        System.out.println("Product Cost    : Rs" + product_cost);
        System.out.println("Product Quantity: " + product_quantity);
        System.out.println("---------------------------");
    }


    static void showCount() {
        System.out.println("Total Objects Created: " + count);
    }
}


public class ProductDemo {
    public static void main(String[] args) {
    
        Product p1 = new Product();  // Default constructor
        Product p2 = new Product(101, "Laptop", 55000.0, 2);
        Product p3 = new Product(102, "Mobile", 25000.0, 5);
        Product p4 = new Product(103, "Headphones", 1500.0, 10);


        System.out.println("\n--- Product Details ---");
        p1.display();
        p2.display();
        p3.display();
        p4.display();


        if (p1 instanceof Marker) {
            System.out.println("Product class implements the Marker interface.");
        }


        Product.showCount();
    }
}

