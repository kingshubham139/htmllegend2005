/*Write a java program that take input as a person name in the format of first, middle
and last name and then print it in the form last, first and middle name, where in the
middle name first character is capital letter */

import java.util.Scanner;

public class PersonNameFormat {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input: First, Middle, Last
        System.out.print("Enter First Name: ");
        String first = sc.nextLine();

        System.out.print("Enter Middle Name: ");
        String middle = sc.nextLine();

        System.out.print("Enter Last Name: ");
        String last = sc.nextLine();

        // Make first letter of middle name uppercase
        String formattedMiddle = middle.substring(0, 1).toUpperCase() + middle.substring(1).toLowerCase();

        // Output: Last, First, Middle
        System.out.println("\nFormatted Name:");
        System.out.println(last + " " + first + " " + formattedMiddle);
    }
}
