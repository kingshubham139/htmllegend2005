

class Employee {
    int id;
    String name;
    String deptName;
    double salary;

    // Static variable to keep count of objects
    static int count = 0;

    // Default constructor
    Employee() {
        this.id = 0;
        this.name = "Not Assigned";
        this.deptName = "Not Assigned";
        this.salary = 0.0;
        count++;
    }

    // Parameterized constructor
    Employee(int id, String name, String deptName, double salary) {
        this.id = id;
        this.name = name;
        this.deptName = deptName;
        this.salary = salary;
        count++;
    }

    // Static method to display count
    static void displayCount() {
        System.out.println("Total objects created: " + count);
    }

    // Method to display employee details
    void displayEmployee() {
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Department: " + deptName);
        System.out.println("Salary: " + salary);
        System.out.println("-----------------------------");
    }

    // Main method
    public static void main(String[] args) {
        Employee e1 = new Employee(101, "Tejas", "IT", 50000);
        e1.displayEmployee();
        Employee.displayCount();

        Employee e2 = new Employee(102, "Ravi", "HR", 45000);
        e2.displayEmployee();
        Employee.displayCount();

        Employee e3 = new Employee(103, "Priya", "Finance", 60000);
        e3.displayEmployee();
        Employee.displayCount();

		 Employee e4 = new Employee(104, "Priya", "Finance", 60000);
        e4.displayEmployee();
        Employee.displayCount();
    }
}
