package TY;
import java.io.BufferedReader;
import java.io.*;
public class SYMarks {
public int ct,mt,et;
public void get() throws IOException
{
System.out.println("Enter marks for comp,maths & ele sub out of 200");
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
ct=Integer.parseInt(br.readLine());
mt=Integer.parseInt(br.readLine());
et=Integer.parseInt(br.readLine());
}

}
