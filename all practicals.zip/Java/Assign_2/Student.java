/*Define Student class(roll_no, name, percentage) to create n objects of the Student class. Accept details from the user for each object. Define a static
method �sortStudent� which sorts the array on the basis of percentage */


import java.util.Scanner;

class Student {
    int roll_no;
    String name;
    float percentage;

    // Constructor
    Student(int roll_no, String name, float percentage) {
        this.roll_no = roll_no;
        this.name = name;
        this.percentage = percentage;
    }

    // Display student info
    void display() {
        System.out.println("Roll No: " + roll_no);
        System.out.println("Name: " + name);
        System.out.println("Percentage: " + percentage);
        System.out.println("---------------------------");
    }

    // Static method to sort students by percentage
    static void sortStudent(Student[] sArr) {
        int n = sArr.length;
        for(int i = 0; i < n - 1; i++) {
            for(int j = i + 1; j < n; j++) {
                if(sArr[i].percentage > sArr[j].percentage) {
                    // swap
                    Student temp = sArr[i];
                    sArr[i] = sArr[j];
                    sArr[j] = temp;
                }
            }
        }

        System.out.println("\n--- Students Sorted by Percentage ---");
        for(Student s : sArr) {
            s.display();
        }
    }

    // Main method
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of students: ");
        int n = sc.nextInt();
        Student[] sArr = new Student[n];

        // Accepting student details
        for(int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Student " + (i+1));
            System.out.print("Roll No: ");
            int roll = sc.nextInt();
            sc.nextLine(); // consume newline

            System.out.print("Name: ");
            String name = sc.nextLine();

            System.out.print("Percentage: ");
            float percent = sc.nextFloat();

            sArr[i] = new Student(roll, name, percent);
        }

        // Sorting using static method
        sortStudent(sArr);
    }
}
