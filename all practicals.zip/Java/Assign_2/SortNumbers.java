/*Write a java program to accept 5 numbers using command line arguments sort and
display them */

public class SortNumbers {
    public static void main(String[] args) {
        // Check if 5 arguments are passed
        if(args.length != 5) {
            System.out.println("Please enter exactly 5 numbers as command line arguments.");
            return;
        }

        // Create an array to store numbers
        int[] numbers = new int[5];

        // Convert string arguments to integers
        for(int i = 0; i < 5; i++) {
            numbers[i] = Integer.parseInt(args[i]);
        }

        // Sorting using simple Bubble Sort
        for(int i = 0; i < 4; i++) {
            for(int j = i + 1; j < 5; j++) {
                if(numbers[i] > numbers[j]) {
                    // swap
                    int temp = numbers[i];
                    numbers[i] = numbers[j];
                    numbers[j] = temp;
                }
            }
        }

        // Display sorted numbers
        System.out.println("Sorted numbers:");
        for(int num : numbers) {
            System.out.print(num + " ");
        }
    }
}
