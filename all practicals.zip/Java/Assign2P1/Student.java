import SY.SYMarks;
import TY.TYMarks;
import java.util.Scanner;
public class Student { 
int rollNumber;
String name;
SYMarks syMarks;
TYMarks tyMarks;
String grade;
public Student(int rollNumber, String name, SYMarks syMarks, TYMarks tyMarks) {
this.rollNumber = rollNumber;
this.name = name;
this.syMarks = syMarks;
this.tyMarks = tyMarks;
calculateGrade();
}
private void calculateGrade() {
int totalComputerMarks = syMarks.computerTotal + tyMarks.theory + tyMarks.practicals;
if (totalComputerMarks >= 70) {
grade = "A";
} else if (totalComputerMarks >= 60) {
grade = "B";
} else if (totalComputerMarks >= 50) {
grade = "C";
} else if (totalComputerMarks >= 40) {
grade = "Pass Class";
} else {
grade = "FAIL";
}
}
public void displayResult() {
System.out.println("Roll Number: " + rollNumber);
System.out.println("Name: " + name);
System.out.println("SY Computer Marks: " + syMarks.computerTotal);
System.out.println("TY Theory Marks: " + tyMarks.theory);
System.out.println("TY Practicals Marks: " + tyMarks.practicals);
System.out.println("Grade: " + grade);
System.out.println("-----------------------------------");
}
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
System.out.print("Enter the number of students: ");
int n = scanner.nextInt();
scanner.nextLine(); // Consume newline
Student[] students = new Student[n];
for (int i = 0; i < n; i++) {
System.out.println("Enter details for Student " + (i + 1) + ":");
System.out.print("Roll Number: ");
int rollNumber = scanner.nextInt();
scanner.nextLine(); // Consume newline
System.out.print("Name: ");
String name = scanner.nextLine();
System.out.print("SY Computer Marks (out of 200): ");
int syComputer = scanner.nextInt();
System.out.print("SY Maths Marks (out of 200): ");
int syMaths = scanner.nextInt();
System.out.print("SY Electronics Marks (out of 200): ");
int syElectronics = scanner.nextInt();
System.out.print("TY Theory Marks (out of 400): ");
int tyTheory = scanner.nextInt();
System.out.print("TY Practicals Marks (out of 200): ");
int tyPracticals = scanner.nextInt();
SYMarks syMarks = new SYMarks(syComputer, syMaths, syElectronics);
TYMarks tyMarks = new TYMarks(tyTheory, tyPracticals);
students[i] = new Student(rollNumber, name, syMarks, tyMarks);
}
System.out.println("\n--- Student Results ---");
for (Student student : students) {
student.displayResult();
}
scanner.close();
}
}
