import java.io.*;
import java.util.*;

public class FileReadExample {
    public static void main(String[] args) {

        String filePath = "sample.txt";

        try {
            File file = new File(filePath);
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;
            List<String> lines = new ArrayList<>();


            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
            br.close();


            System.out.println("----- Original Content in UPPERCASE -----");
            for (String l : lines) {
                System.out.println(l.toUpperCase());
            }


            System.out.println("\n----- Content in REVERSE ORDER -----");
            for (int i = lines.size() - 1; i >= 0; i--) {
                System.out.println(lines.get(i));
            }

        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}

