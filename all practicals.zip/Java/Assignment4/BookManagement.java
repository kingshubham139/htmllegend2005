import java.io.*;
import java.util.Scanner;

class Book {
    int bookId;
    String bookName;
    double bookPrice;
    int bookQty;

    // Constructor
    Book(int id, String name, double price, int qty) {
        this.bookId = id;
        this.bookName = name;
        this.bookPrice = price;
        this.bookQty = qty;
    }

    // Default constructor
    Book() {}
}

public class BookManagement {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        try {
            RandomAccessFile raf = new RandomAccessFile("book.dat", "rw");
            int choice;

            do {
                System.out.println("\n----- BOOK MENU -----");
                System.out.println("1. Add Book");
                System.out.println("2. Search Book by Name");
                System.out.println("3. Display All Books and Total Cost");
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");
                choice = sc.nextInt();
                sc.nextLine(); // consume newline

                switch (choice) {
                    case 1:
                        addBook(raf);
                        break;
                    case 2:
                        searchBook(raf);
                        break;
                    case 3:
                        displayAllBooks(raf);
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice!");
                }
            } while (choice != 4);

            raf.close();
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Method to add book
    static void addBook(RandomAccessFile raf) throws IOException {
        System.out.print("Enter Book ID: ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Book Name: ");
        String name = sc.nextLine();
        System.out.print("Enter Book Price: ");
        double price = sc.nextDouble();
        System.out.print("Enter Book Quantity: ");
        int qty = sc.nextInt();
        sc.nextLine();

        // Write data in fixed format
        raf.seek(raf.length()); // move to end of file
        raf.writeInt(id);

        // Write string with fixed length 30 chars
        StringBuffer sb = new StringBuffer(name);
        sb.setLength(30); // pad or trim to 30 chars
        raf.writeChars(sb.toString());

        raf.writeDouble(price);
        raf.writeInt(qty);

        System.out.println("Book added successfully!");
    }

    // Method to search book by name
    static void searchBook(RandomAccessFile raf) throws IOException {
        System.out.print("Enter Book Name to search: ");
        String searchName = sc.nextLine();

        raf.seek(0); // go to start
        boolean found = false;

        while (raf.getFilePointer() < raf.length()) {
            int id = raf.readInt();
            char nameChars[] = new char[30];
            for (int i = 0; i < 30; i++) {
                nameChars[i] = raf.readChar();
            }
            String name = new String(nameChars).trim();

            double price = raf.readDouble();
            int qty = raf.readInt();

            if (name.equalsIgnoreCase(searchName)) {
                System.out.println("\nBook Found:");
                System.out.println("ID: " + id);
                System.out.println("Name: " + name);
                System.out.println("Price: " + price);
                System.out.println("Quantity: " + qty);
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Book not found!");
        }
    }

    // Method to display all books and total cost
    static void displayAllBooks(RandomAccessFile raf) throws IOException {
        raf.seek(0); // go to start
        double totalCost = 0;
        boolean hasBooks = false;

        System.out.println("\n--- All Books ---");
        while (raf.getFilePointer() < raf.length()) {
            int id = raf.readInt();

            char nameChars[] = new char[30];
            for (int i = 0; i < 30; i++) {
                nameChars[i] = raf.readChar();
            }
            String name = new String(nameChars).trim();

            double price = raf.readDouble();
            int qty = raf.readInt();

            System.out.println("ID: " + id + ", Name: " + name + ", Price: " + price + ", Quantity: " + qty);
            totalCost += price * qty;
            hasBooks = true;
        }

        if (hasBooks) {
            System.out.println("Total Cost of All Books: " + totalCost);
        } else {
            System.out.println("No books found.");
        }
    }
}
