
class CovidPositiveException extends Exception {
    public CovidPositiveException(String message) {
        super(message);
    }
}


class Patient {
    String patient_name;
    int patient_age;
    int patient_oxy_level;
    int patient_HRCT_report;


    public Patient(String name, int age, int oxy, int hrct) {
        this.patient_name = name;
        this.patient_age = age;
        this.patient_oxy_level = oxy;
        this.patient_HRCT_report = hrct;
    }


    public void displayInfo() {
        System.out.println("Patient Name: " + patient_name);
        System.out.println("Patient Age: " + patient_age);
        System.out.println("Oxygen Level: " + patient_oxy_level + "%");
        System.out.println("HRCT Report: " + patient_HRCT_report);
    }


    public void checkHealth() throws CovidPositiveException {
        if (patient_oxy_level < 95 && patient_HRCT_report > 10) {
            throw new CovidPositiveException("Patient is Covid Positive(+) and Need to Hospitalized");
        } else {
            displayInfo();
        }
    }
}


public class Main {
    public static void main(String[] args) {

        Patient p1 = new Patient("Ganesh T", 30, 96, 9);


        try {
            p1.checkHealth();
        } catch (CovidPositiveException e) {
            System.out.println(e.getMessage());
        }
    }
}
