import java.io.*;
import java.util.Scanner;

public class FileCopyWithComment {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);


        System.out.print("Enter the name of the first file: ");
        String firstFile = sc.nextLine();
        System.out.print("Enter the name of the second file: ");
        String secondFile = sc.nextLine();

        try {

            FileReader fr = new FileReader(firstFile);
            BufferedReader br = new BufferedReader(fr);


            FileWriter fw = new FileWriter(secondFile);
            BufferedWriter bw = new BufferedWriter(fw);

            String line;
            while ((line = br.readLine()) != null) {
                bw.write(line);      
                bw.newLine();        
            }


            bw.write("end of file");
            bw.newLine();


            br.close();
            bw.close();

            System.out.println("Contents copied successfully and comment added...");
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}
