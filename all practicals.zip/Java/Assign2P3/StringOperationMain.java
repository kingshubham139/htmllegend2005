import stringop.Con;
import stringop.Comp;
import java.util.Scanner;
public class StringOperationMain {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
// Take two strings from user
System.out.print("Enter first string: ");
String str1 = sc.nextLine();
System.out.print("Enter second string: ");
String str2 = sc.nextLine();
// Create objects for operations
Con conObj = new Con();
Comp compObj = new Comp();
// Perform operations
System.out.println("\n--- String Operations ---");
conObj.concatenate(str1, str2);
compObj.compare(str1, str2);
sc.close();
}
}

/*      javac -d . Con.java

	javac -d . Comp.java
*/


















