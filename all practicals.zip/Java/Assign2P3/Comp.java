package stringop;
public class Comp 
{
	public void compare(String s1, String s2)
	{
	if (s1.equals(s2))
	{
	System.out.println("Strings are EQUAL.");
	}
	else
	{
	System.out.println("Strings are NOT equal.");
	}
	}
}
