#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
pid_t pid = fork();

if (pid < 0) {
perror("fork failed");
return 1;
}
else if (pid == 0) {
// child process
printf("Child Process started.\n");
printf("Child PID: %d, Parent PID: %d\n", getpid(),getppid());

//sleep to allow parent to terminate
sleep(5);

//After parent has terminated,PPID changes to init process (usually PID 1)
printf("After parent termination:\n");
printf("Child PID: %d, New Parent PID: %d\n", getpid(),getppid());
}
else
//parent process
printf("Parent Process PID:%d\n", getpid());
printf("Parent terminating immeditely.\n");
//parent terminates immediately,child becomes orphan
}

return 0;
}


