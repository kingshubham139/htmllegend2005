#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<wait.h>

// Bubble sort function
void bubblesort(int arr[ ] , int n) {
int i, j, temp;
for(i=0; i<n-1; i++) {
for(j=0; j<n-i-1; j++) {
if(arr[j] > arr[j+1]) {
temp = arr[j];
arr[j] = arr[j+1];
arr[j+1] = temp;
}
}
}
}

int main() {
int n;
printf("Enter  number of elements: ");
scanf("%d", &n);

int arr[n];
printf("Enter %d integers:\n",n);
for(int i=0; i<n; i++) {
scanf("%d", &arr[i]);
}

int key;
printf("Enter the number to search:");
scanf("%d", &key);

// sort array
bubblesort(arr,n);

pid_t pid = fork();

if(pid < 0) {
perror("fork failed");
exit(1);
}
else if(pid ==0) {


char **args = malloc((n + 4) * sizeof(char *));
if(!args) {
perror("malloc failed");
exit(1);
}

args[0] = "./child_search";

char buffer[20];

// n as string
snprintf(buffer, sizeof(buffer), "%d",n);
args[1]= Strdup(buffer);

// sorted array elements as strings
for(int i=0; i<n; i++) {
snprintf(buffer, sizeof(buffer), "%d", arr[i]);
args[i+2] = strdup(buffer);
}

// key as string
snprintf(buffer,sizeof(buffer),"%d", key);
args[n+2] = Strdup(buffer);

args[n+3] = NULL;

execve("./child_search", args,NULL);

perror("execve failed");
exit(1);
}
else {
// parent waits for child to finish
wait(NULL);
}

return 0;
}


