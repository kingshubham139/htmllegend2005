#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_LINE 1024
#define MAX_ARGS 100

void tokenize(char *line, char **args, int *argc) {
    *argc = 0;
    char *token = strtok(line, " \t\n");
    while (token != NULL && *argc < MAX_ARGS - 1) {
        args[(*argc)++] = token;
        token = strtok(NULL, " \t\n");
    }
    args[*argc] = NULL;
}

void print_first_n_lines(const char *filename, int n) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("fopen");
        return;
    }
    char buffer[1024];
    int count = 0;
    while (fgets(buffer, sizeof(buffer), fp) && count < n) {
        fputs(buffer, stdout);
        count++;
    }
    fclose(fp);
}

void print_all_lines(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("fopen");
        return;
    }
    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), fp)) {
        fputs(buffer, stdout);
    }
    fclose(fp);
}

void print_last_n_lines(const char *filename, int n) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("fopen");
        return;
    }

    // Count total lines
    int total_lines = 0;
    char buffer[1024];
    while (fgets(buffer, sizeof(buffer), fp)) {
        total_lines++;
    }

    int start_line = total_lines - n;
    if (start_line < 0) start_line = 0;

    fseek(fp, 0, SEEK_SET);

    int current_line = 0;
    while (fgets(buffer, sizeof(buffer), fp)) {
        if (current_line >= start_line) {
            fputs(buffer, stdout);
        }
        current_line++;
    }

    fclose(fp);
}

int main() {
    char line[MAX_LINE];
    char *args[MAX_ARGS];
    int argc;

    while (1) {
        printf("myshell$ ");
        if (!fgets(line, sizeof(line), stdin)) {
            printf("\n");
            break; // EOF or error
        }

        // Remove trailing newline
        line[strcspn(line, "\n")] = 0;

        if (strlen(line) == 0) continue;

        tokenize(line, args, &argc);

        if (argc == 0) continue;

        if (strcmp(args[0], "exit") == 0) {
            break;
        }

        if (strcmp(args[0], "typeline") == 0) {
            if (argc != 3) {
                fprintf(stderr, "Usage:\n");
                fprintf(stderr, "typeline n filename\n");
                fprintf(stderr, "typeline -n filename\n");
                fprintf(stderr, "typeline a filename\n");
                continue;
            }

            if (strcmp(args[1], "a") == 0) {
                print_all_lines(args[2]);
            }
            else if (args[1][0] == '-') {
                int n = atoi(args[1] + 1);
                if (n <= 0) {
                    fprintf(stderr, "Invalid line count: %s\n", args[1] + 1);
                    continue;
                }
                print_last_n_lines(args[2], n);
            }
            else {
                int n = atoi(args[1]);
                if (n <= 0) {
                    fprintf(stderr, "Invalid line count: %s\n", args[1]);
                    continue;
                }
                print_first_n_lines(args[2], n);
            }
            continue;
        }

        // Execute other commands normally
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            continue;
        }
        if (pid == 0) {
            execvp(args[0], args);
            perror("execvp");
            exit(EXIT_FAILURE);
        } else {
            wait(NULL);
        }
    }

    return 0;
}

