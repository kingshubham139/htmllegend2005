#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_LINE 1024
#define MAX_ARGS 100

void tokenize(char *line, char **args, int *argc) {
    *argc = 0;
    char *token = strtok(line, " \t\n");
    while (token != NULL && *argc < MAX_ARGS - 1) {
        args[(*argc)++] = token;
        token = strtok(NULL, " \t\n");
    }
    args[*argc] = NULL;
}

void search_first_occurrence(const char *filename, const char *pattern) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("fopen");
        return;
    }
    char line[MAX_LINE];
    int line_num = 1;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, pattern) != NULL) {
            printf("Found at line %d: %s", line_num, line);
            fclose(fp);
            return;
        }
        line_num++;
    }
    printf("Pattern not found\n");
    fclose(fp);
}

void search_all_occurrences(const char *filename, const char *pattern) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("fopen");
        return;
    }
    char line[MAX_LINE];
    int line_num = 1;
    int found = 0;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, pattern) != NULL) {
            printf("Line %d: %s", line_num, line);
            found = 1;
        }
        line_num++;
    }
    if (!found) {
        printf("Pattern not found\n");
    }
    fclose(fp);
}

void count_occurrences(const char *filename, const char *pattern) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("fopen");
        return;
    }
    char line[MAX_LINE];
    int count = 0;
    size_t pat_len = strlen(pattern);
    while (fgets(line, sizeof(line), fp)) {
        char *ptr = line;
        while ((ptr = strstr(ptr, pattern)) != NULL) {
            count++;
            ptr += pat_len; // move past current match
        }
    }
    printf("Total occurrences: %d\n", count);
    fclose(fp);
}

int main() {
    char line[MAX_LINE];
    char *args[MAX_ARGS];
    int argc;

    while (1) {
        printf("myshell$ ");
        if (!fgets(line, sizeof(line), stdin)) {
            printf("\n");
            break; // EOF or error
        }

        line[strcspn(line, "\n")] = 0; // strip newline

        if (strlen(line) == 0) continue;

        tokenize(line, args, &argc);

        if (argc == 0) continue;

        if (strcmp(args[0], "exit") == 0) {
            break;
        }

        if (strcmp(args[0], "search") == 0) {
            // search f filename pattern
            // search a filename pattern
            // search c filename pattern
            if (argc != 4) {
                fprintf(stderr, "Usage:\n");
                fprintf(stderr, "search f filename pattern\n");
                fprintf(stderr, "search a filename pattern\n");
                fprintf(stderr, "search c filename pattern\n");
                continue;
            }

            char mode = args[1][0];
            const char *filename = args[2];
            const char *pattern = args[3];

            if (mode == 'f') {
                search_first_occurrence(filename, pattern);
            } else if (mode == 'a') {
                search_all_occurrences(filename, pattern);
            } else if (mode == 'c') {
                count_occurrences(filename, pattern);
            } else {
                fprintf(stderr, "Invalid mode: %c\n", mode);
                fprintf(stderr, "Valid modes: f, a, c\n");
            }
            continue;
        }

        // Otherwise execute normal command by forking
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            continue;
        }
        if (pid == 0) {
            execvp(args[0], args);
            perror("execvp");
            exit(EXIT_FAILURE);
        } else {
            wait(NULL);
        }
    }

    return 0;
}

