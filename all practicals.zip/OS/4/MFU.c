#include <stdio.h>

#define REF_LEN 16
int reference_string[REF_LEN] = {12, 15, 12, 18, 6, 8, 11, 12, 19, 12, 6, 8, 12, 15, 19, 8};

// Check if a page is in memory and return its index
int find_in_memory(int memory[], int n, int page) {
    for (int i = 0; i < n; i++) {
        if (memory[i] == page)
            return i;
    }
    return -1;
}

// Find the index of the most frequently used page
int find_mfu(int memory[], int freq[], int n) {
    int max_freq = -1;
    int index = -1;
    for (int i = 0; i < n; i++) {
        if (freq[i] > max_freq) {
            max_freq = freq[i];
            index = i;
        }
    }
    return index;
}

void mfu(int n) {
    int memory[n];
    int freq[n];  // frequency count for each page in memory
    int page_faults = 0;

    // Initialize memory and frequency
    for (int i = 0; i < n; i++) {
        memory[i] = -1;
        freq[i] = 0;
    }

    printf("\n--- MFU (Most Frequently Used) Page Replacement ---\n");

    for (int i = 0; i < REF_LEN; i++) {
        int page = reference_string[i];
        int found_index = find_in_memory(memory, n, page);

        if (found_index != -1) {
            // Page Hit: increase frequency
            freq[found_index]++;
        } else {
            // Page Fault
            int replace_index = -1;

            // Look for empty frame
            for (int j = 0; j < n; j++) {
                if (memory[j] == -1) {
                    replace_index = j;
                    break;
                }
            }

            // If no empty frame, replace the most frequently used page
            if (replace_index == -1) {
                replace_index = find_mfu(memory, freq, n);
            }

            // Replace the page
            memory[replace_index] = page;
            freq[replace_index] = 1;  // reset frequency for new page
            page_faults++;
        }

        // Print memory state
        printf("Step %2d: Page %2d -> Memory: ", i + 1, page);
        for (int j = 0; j < n; j++) {
            if (memory[j] != -1)
                printf("%2d ", memory[j]);
            else
                printf(" - ");
        }
        printf("\n");
    }

    printf("Total Page Faults (MFU): %d\n", page_faults);
}

// Main function
int main() {
    int n;

    printf("Enter the number of memory frames: ");
    scanf("%d", &n);

    mfu(n);

    return 0;
}

