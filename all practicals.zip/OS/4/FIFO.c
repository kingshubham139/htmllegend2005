#include <stdio.h>

#define REF_LEN 16
int reference_string[REF_LEN] = {12, 15, 12, 18, 6, 8, 11, 12, 19, 12, 6, 8, 12, 15, 19, 8};

// Function to check if a page is already in memory
int is_in_memory(int memory[], int n, int page) {
    for (int i = 0; i < n; i++) {
        if (memory[i] == page)
            return 1;
    }
    return 0;
}

// FIFO Page Replacement
void fifo(int n) {
    int memory[n];
    int front = 0;            // Pointer to the oldest page
    int page_faults = 0;

    // Initialize memory with -1 (empty)
    for (int i = 0; i < n; i++)
        memory[i] = -1;

    printf("\n--- FIFO Page Replacement ---\n");

    for (int i = 0; i < REF_LEN; i++) {
        int page = reference_string[i];

        // Page not in memory => page fault
        if (!is_in_memory(memory, n, page)) {
            memory[front] = page;
            front = (front + 1) % n;  // Replace oldest page
            page_faults++;
        }

        // Print current memory state
        printf("Step %2d: Page %2d -> Memory: ", i + 1, page);
        for (int j = 0; j < n; j++) {
            if (memory[j] != -1)
                printf("%2d ", memory[j]);
            else
                printf(" - ");
        }
        printf("\n");
    }

    printf("Total Page Faults (FIFO): %d\n", page_faults);
}

// Main Function
int main() {
    int n;

    printf("Enter the number of memory frames: ");
    scanf("%d", &n);

    fifo(n);

    return 0;
}

