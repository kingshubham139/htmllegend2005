#include <stdio.h>

#define REF_LEN 16
int reference_string[REF_LEN] = {12, 15, 12, 18, 6, 8, 11, 12, 19, 12, 6, 8, 12, 15, 19, 8};

// Function to check if page is in memory
int is_in_memory(int memory[], int n, int page) {
    for (int i = 0; i < n; i++) {
        if (memory[i] == page)
            return i;
    }
    return -1;
}

// Function to find the least recently used page index
int find_lru(int used[], int n) {
    int min = used[0], idx = 0;
    for (int i = 1; i < n; i++) {
        if (used[i] < min) {
            min = used[i];
            idx = i;
        }
    }
    return idx;
}

// LRU Implementation
void lru(int n) {
    int memory[n];      // Holds pages in memory
    int used[n];        // Timestamps of when each frame was last used
    int time = 0;       // Simulated time
    int page_faults = 0;

    // Initialize memory and usage tracking
    for (int i = 0; i < n; i++) {
        memory[i] = -1;
        used[i] = 0;
    }

    printf("\n--- LRU Page Replacement ---\n");

    for (int i = 0; i < REF_LEN; i++) {
        int page = reference_string[i];
        time++;  // Advance simulated time

        int pos = is_in_memory(memory, n, page);

        if (pos != -1) {
            // Page Hit: update usage time
            used[pos] = time;
        } else {
            // Page Fault
            int replace_idx = -1;

            // Check for empty frame
            for (int j = 0; j < n; j++) {
                if (memory[j] == -1) {
                    replace_idx = j;
                    break;
                }
            }

            // No empty frame, replace LRU
            if (replace_idx == -1)
                replace_idx = find_lru(used, n);

            memory[replace_idx] = page;
            used[replace_idx] = time;
            page_faults++;
        }

        // Print current memory state
        printf("Step %2d: Page %2d -> Memory: ", i + 1, page);
        for (int j = 0; j < n; j++) {
            if (memory[j] != -1)
                printf("%2d ", memory[j]);
            else
                printf(" - ");
        }
        printf("\n");
    }

    printf("Total Page Faults (LRU): %d\n", page_faults);
}

// Main Function
int main() {
    int n;

    printf("Enter the number of memory frames: ");
    scanf("%d", &n);

    lru(n);

    return 0;
}

