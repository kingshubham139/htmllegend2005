#include <stdio.h>
#include <unistd.h>   // for fork()
#include <sys/types.h> // for pid_t

int main() {
    pid_t pid;

    pid = fork();  // Create child process

    if (pid < 0) {
        // Fork failed
        perror("Fork failed");
        return 1;
    }
    else if (pid == 0) {
        // Child process
        printf("I am Child Process\n");
        printf("Child Process ID: %d\n", getpid());
    }
    else {
        // Parent process
        printf("I am Parent Process\n");
        printf("Parent Process ID: %d\n", getpid());
    }

    return 0;
}
