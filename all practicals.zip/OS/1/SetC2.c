#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork failed");
        return 1;
    }
    else if (pid == 0) {
        // Child process

        // Replace child process with new program using exec()
        // Assuming the program to execute is "./programA1"
        char *args[] = {"programA1", NULL};
        execvp(args[0], args);

        // execvp returns only if it fails
        perror("exec failed");
        return 1;
    }
    else {
        // Parent process
        printf("I am parent\n");

        // Optional: wait for child to finish
        wait(NULL);
    }

    return 0;
}

