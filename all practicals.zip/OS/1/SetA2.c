#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <stdlib.h>

int main() {
    pid_t pid;

    pid = fork();

    if (pid < 0) {
        perror("fork failed");
        return 1;
    }
    else if (pid == 0) {
        // Child process
        printf("Child process before nice(): current nice value = %d\n", nice(0));

        // Increase nice value by 5 (lower priority)
        int ret = nice(5);
        if (ret == -1) {
            perror("nice failed");
        }

        printf("Child process after nice(): new nice value = %d\n", nice(0));
        printf("Child PID: %d\n", getpid());

        // simulate some work
        for (int i = 0; i < 5; i++) {
            printf("Child working...\n");
            sleep(1);
        }
    }
    else {
        // Parent process
        printf("Parent PID: %d\n", getpid());
        printf("Parent process priority (nice value) = %d\n", nice(0));

        // simulate some work
        for (int i = 0; i < 5; i++) {
            printf("Parent working...\n");
            sleep(1);
        }
    }

    return 0;
}

