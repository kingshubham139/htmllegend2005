#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define IO_WAIT_TIME 2 // Fixed I/O waiting time

// Structure to represent a process
struct Process {
    int pid;
    int arrivalTime;
    int initialBurst; // First CPU burst
    int remainingBurst; // Remaining CPU burst time
    int ioBurst; // Time spent in I/O
    int waitingTime;
    int turnaroundTime;
    int completionTime;
    int lastExecutionTime; // Time when process last ran or entered ready queue
    int state; // 0: Ready, 1: Running, 2: I/O, 3: Completed
};

// Function to generate a random next CPU burst
int generateRandomBurst() {
    return (rand() % 10) + 1; // Random burst between 1 and 10
}

void roundRobinScheduling(struct Process processes[], int n, int timeQuantum) {
    int currentTime = 0;
    int completedProcesses = 0;
    int *readyQueue = (int *)malloc(n * sizeof(int)); // Stores PIDs in ready queue
    int head = 0, tail = 0;

    // Initialize random seed
    srand(time(NULL));

    // Initialize processes
    for (int i = 0; i < n; i++) {
        processes[i].remainingBurst = processes[i].initialBurst;
        processes[i].ioBurst = 0;
        processes[i].waitingTime = 0;
        processes[i].turnaroundTime = 0;
        processes[i].completionTime = 0;
        processes[i].lastExecutionTime = processes[i].arrivalTime; // Initially, last execution time is arrival time
        processes[i].state = 0; // All processes are initially in ready state
    }

    printf("\n--- Gantt Chart ---\n");

    while (completedProcesses < n) {
        // Add newly arrived processes to the ready queue
        for (int i = 0; i < n; i++) {
            if (processes[i].state == 0 && processes[i].arrivalTime <= currentTime) {
                readyQueue[tail++] = i; // Add process index to queue
                processes[i].state = 0; // Mark as ready (already 0, but for clarity)
            }
        }

        // Handle I/O completion
        for (int i = 0; i < n; i++) {
            if (processes[i].state == 2 && processes[i].ioBurst <= 0) {
                processes[i].state = 0; // Move to ready state
                processes[i].remainingBurst = generateRandomBurst(); // Generate next CPU burst
                readyQueue[tail++] = i; // Add to ready queue
            }
        }

        if (head == tail) { // CPU is idle
            printf("| Idle (%d-%d) ", currentTime, currentTime + 1);
            currentTime++;
            continue;
        }

        int currentProcessIndex = readyQueue[head++]; // Get process from ready queue

        if (processes[currentProcessIndex].state == 0) { // If process is ready
            processes[currentProcessIndex].state = 1; // Mark as running
            processes[currentProcessIndex].waitingTime += (currentTime - processes[currentProcessIndex].lastExecutionTime);

            int executionTime = (processes[currentProcessIndex].remainingBurst < timeQuantum) ? processes[currentProcessIndex].remainingBurst : timeQuantum;

            printf("| P%d (%d-%d) ", processes[currentProcessIndex].pid, currentTime, currentTime + executionTime);
            currentTime += executionTime;
            processes[currentProcessIndex].remainingBurst -= executionTime;
            processes[currentProcessIndex].lastExecutionTime = currentTime;

            if (processes[currentProcessIndex].remainingBurst == 0) {
                // Process completes its CPU burst
                processes[currentProcessIndex].completionTime = currentTime;
                processes[currentProcessIndex].turnaroundTime = processes[currentProcessIndex].completionTime - processes[currentProcessIndex].arrivalTime;
                
                // Decide if it's truly completed or needs I/O
                if (processes[currentProcessIndex].initialBurst > 0 && processes[currentProcessIndex].ioBurst == 0) { // Assuming first burst doesn't lead to I/O
                     processes[currentProcessIndex].state = 3; // Truly completed
                     completedProcesses++;
                } else if (processes[currentProcessIndex].ioBurst == 0) { // Subsequent bursts can lead to I/O
                    processes[currentProcessIndex].state = 2; // Move to I/O state
                    processes[currentProcessIndex].ioBurst = IO_WAIT_TIME;
                } else { // Process was in I/O and now completed its CPU burst
                    processes[currentProcessIndex].state = 3; // Truly completed
                    completedProcesses++;
                }
            } else {
                // Process is preempted, add back to ready queue
                processes[currentProcessIndex].state = 0;
                readyQueue[tail++] = currentProcessIndex;
            }
        }

        // Decrement I/O burst for processes in I/O state
        for (int i = 0; i < n; i++) {
            if (processes[i].state == 2 && i != currentProcessIndex) {
                processes[i].ioBurst--;
            }
        }
    }
    printf("|\n");
    free(readyQueue);
}

int main() {
    int n, timeQuantum;

    printf("Enter the number of processes: ");
    scanf("%d", &n);

    struct Process processes[n];

    for (int i = 0; i < n; i++) {
        processes[i].pid = i + 1;
        printf("Enter arrival time for Process P%d: ", i + 1);
        scanf("%d", &processes[i].arrivalTime);
        printf("Enter initial CPU burst time for Process P%d: ", i + 1);
        scanf("%d", &processes[i].initialBurst);
    }

    printf("Enter the time quantum: ");
    scanf("%d", &timeQuantum);

    roundRobinScheduling(processes, n, timeQuantum);

    printf("\n--- Process Details ---\n");
    printf("PID\tArrival\tInitial Burst\tCompletion\tTurnaround\tWaiting\n");

    double totalWaitingTime = 0;
    double totalTurnaroundTime = 0;

    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t\t%d\t\t%d\t\t%d\n",
               processes[i].pid,
               processes[i].arrivalTime,
               processes[i].initialBurst,
               processes[i].completionTime,
               processes[i].turnaroundTime,
               processes[i].waitingTime);
        totalWaitingTime += processes[i].waitingTime;
        totalTurnaroundTime += processes[i].turnaroundTime;
    }

    printf("\nAverage Waiting Time: %.2f\n", totalWaitingTime / n);
    printf("Average Turnaround Time: %.2f\n", totalTurnaroundTime / n);

    return 0;
}
