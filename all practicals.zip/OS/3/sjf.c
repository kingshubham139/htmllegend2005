#include <stdio.h>
#include <limits.h> // For INT_MAX

// Structure to represent a process
struct Process {
    int pid;         // Process ID
    int arrival_time; // Arrival time
    int burst_time;  // Burst time
    int remaining_time; // Remaining burst time
    int completion_time;
    int turnaround_time;
    int waiting_time;
};

void sjf_preemptive_scheduling(struct Process processes[], int n) {
    int current_time = 0;
    int completed_processes = 0;
    int shortest_job_index = -1;
    int min_remaining_time = INT_MAX;

    // Initialize remaining_time for all processes
    for (int i = 0; i < n; i++) {
        processes[i].remaining_time = processes[i].burst_time;
    }

    while (completed_processes < n) {
        shortest_job_index = -1;
        min_remaining_time = INT_MAX;

        // Find the process with the shortest remaining time among arrived processes
        for (int i = 0; i < n; i++) {
            if (processes[i].arrival_time <= current_time && processes[i].remaining_time > 0) {
                if (processes[i].remaining_time < min_remaining_time) {
                    min_remaining_time = processes[i].remaining_time;
                    shortest_job_index = i;
                }
            }
        }

        if (shortest_job_index == -1) {
            // No process is ready to execute, advance time
            current_time++;
            continue;
        }

        // Execute the shortest job for one time unit
        processes[shortest_job_index].remaining_time--;
        current_time++;

        // Check if the process has completed
        if (processes[shortest_job_index].remaining_time == 0) {
            completed_processes++;
            processes[shortest_job_index].completion_time = current_time;
            processes[shortest_job_index].turnaround_time = processes[shortest_job_index].completion_time - processes[shortest_job_index].arrival_time;
            processes[shortest_job_index].waiting_time = processes[shortest_job_index].turnaround_time - processes[shortest_job_index].burst_time;
        }
    }
}

int main() {
    int n;
    printf("Enter the number of processes: ");
    scanf("%d", &n);

    struct Process processes[n];

    for (int i = 0; i < n; i++) {
        processes[i].pid = i + 1;
        printf("Enter arrival time for process P%d: ", i + 1);
        scanf("%d", &processes[i].arrival_time);
        printf("Enter burst time for process P%d: ", i + 1);
        scanf("%d", &processes[i].burst_time);
    }

    sjf_preemptive_scheduling(processes, n);

    printf("\nProcess\tArrival Time\tBurst Time\tCompletion Time\tTurnaround Time\tWaiting Time\n");
    float total_turnaround_time = 0;
    float total_waiting_time = 0;

    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t\t%d\t\t%d\t\t%d\t\t%d\n",
               processes[i].pid,
               processes[i].arrival_time,
               processes[i].burst_time,
               processes[i].completion_time,
               processes[i].turnaround_time,
               processes[i].waiting_time);
        total_turnaround_time += processes[i].turnaround_time;
        total_waiting_time += processes[i].waiting_time;
    }

    printf("\nAverage Turnaround Time: %.2f\n", total_turnaround_time / n);
    printf("Average Waiting Time: %.2f\n", total_waiting_time / n);

    return 0;
}
