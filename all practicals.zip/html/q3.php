<!DOCTYPE html>
<html>
<head>
    <title>String Comparison Operations</title>
</head>
<body>

<h2>String Operations</h2>
<form method="post">
    Enter First String (Big String): <input type="text" name="bigStr" required><br><br>
    Enter Second String (Small String): <input type="text" name="smallStr" required><br><br>
    Enter Number of Characters for Comparison: <input type="number" name="n" min="1" required><br><br>

    <input type="submit" name="submit" value="Check Results">
</form>

<?php
// Function to check if small string appears at the start of large string
function startsWithString($big, $small) {
    return stripos($big, $small) === 0; // Case-insensitive check
}

// Function to find position of small string in big string
function findPosition($big, $small) {
    $pos = stripos($big, $small); // Case-insensitive position
    return ($pos !== false) ? $pos + 1 : -1; // +1 for human-readable index
}

// Function to compare first n characters (case-insensitive)
function compareFirstN($str1, $str2, $n) {
    $sub1 = substr($str1, 0, $n);
    $sub2 = substr($str2, 0, $n);
    return strcasecmp($sub1, $sub2) === 0; // 0 means equal
}

if (isset($_POST['submit'])) {
    $bigStr   = $_POST['bigStr'];
    $smallStr = $_POST['smallStr'];
    $n        = intval($_POST['n']);

    echo "<h3>Results:</h3>";

    // a) Check if starts with
    if (startsWithString($bigStr, $smallStr)) {
        echo "a) The small string appears at the start of the big string.<br>";
    } else {
        echo "a) The small string does NOT appear at the start of the big string.<br>";
    }

    // b) Find position
    $pos = findPosition($bigStr, $smallStr);
    if ($pos != -1) {
        echo "b) The small string is found at position: $pos<br>";
    } else {
        echo "b) The small string was NOT found in the big string.<br>";
    }

    // c) Compare first n characters (case-insensitive)
    if (compareFirstN($bigStr, $smallStr, $n)) {
        echo "c) The first $n characters of both strings are the same (case-insensitive).<br>";
    } else {
        echo "c) The first $n characters of both strings are different.<br>";
    }
}
?>

</body>
</html>

