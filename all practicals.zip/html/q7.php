<!DOCTYPE html>
<html>
<head>
    <title>String Operations using substr_replace()</title>
</head>
<body>
    <h2>String Operations</h2>
    <form method="post">
        Enter Big String  <input type="text" name="big"><br><br>
        Enter Small String <input type="text"   name="small"><br><br>
        Enter Position: <input type="number" name="pos"><br><br>
        Enter Number of Characters to Remove: <input type="number" name="len"><br><br>
        <input type="submit" name="submit" value="Perform Operations">
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $big = $_POST['big'];
        $small = $_POST['small'];
        $pos = (int)$_POST['pos'];
        $len = (int)$_POST['len'];

        echo "<h3>Original Big String: $big</h3>";
        echo "<h3>Small String: $small</h3>";
        echo "<h3>Position: $pos | Length: $len</h3>";

        // (a) Delete a part from big string
        $deletePart = substr_replace($big, "", $pos, $len);
        echo "<p><b>a) After Deletion:</b> $deletePart</p>";

        // (b) Insert small string at given position
        $insertPart = substr_replace($big, $small, $pos, 0);
        echo "<p><b>b) After Insertion:</b> $insertPart</p>";

        // (c) Replace some characters with small string
        $replacePart = substr_replace($big, $small, $pos, $len);
        echo "<p><b>c) After Replacing Characters:</b> $replacePart</p>";

        // (d) Replace all characters after position
        $replaceAfter = substr_replace($big, $small, $pos);
        echo "<p><b>d) After Replacing All Characters After Position:</b> $replaceAfter</p>";
    }
    ?>
</body>
</html>

