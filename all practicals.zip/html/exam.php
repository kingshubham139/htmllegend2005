<!DOCTYPE html>
<html>
<head>
<script type="text/javascript">
alert("Exams are near, have you started preparing for?");
let num1 = prompt("Enter the first number:");
let num2 = prompt("Enter the second number:");
num1 = parseFloat(num1);
num2 = parseFloat(num2);
if (isNaN(num1) || isNaN(num2)) {
confirm("Invalid input. Please enter numbers only.");
}
else
{
  const sum = num1 + num2;
  confirm(`The sum of ${num1} and ${num2} is ${sum}.`);
}
</script>
<title></title>
</head>
<body>
</body>
</html>
