alert('Exams are near, have you started preparing for?');
let num1 = prompt("Enter the first number:");
let num2 = prompt("Enter the second number:");
num1 = parseFloat(num1);
num2 = parseFloat(num2);
let proceed = confirm("Do you want to add the two numbers?");

if (proceed) {
    let sum = num1 + num2;
    alert("The sum of the two numbers is: " + sum);
} else {
    alert("You chose not to add the numbers.");
}

