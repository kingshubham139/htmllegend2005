<? php
session_start();
$_SESSION["eno"]=$_POST["t1"];
$_SESSION["enm"]=$_POST["t2"];
$_SESSION["add"]=$_POST["t3"];

echo "<br>hello  ".$_SESSION["enm"]."Plz fill your earning details";
  
  echo"<form method="post" action="display.php">";
  echo "basic  :<input type="text" name="t4"><br>";
   echo "DA  :<input type="text" name="t5"><br>";
    echo "HRA  :<input type="text" name="t6"><br>";
   echo"<input type="submit" value="display"></form>";
   ?>
    
    
    
    
    
    
    
