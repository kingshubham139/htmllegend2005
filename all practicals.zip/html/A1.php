
<html>
<head>
<title> Number of times the web page has been visited. </title>
</head>
<body>
<?php
    session_start();
    if(isset($_SESSION['count']))
    $_SESSION['count']=$_SESSION['count']+1;
    else
    $_SESSION['count']=1;
    echo"<h3>this page is accessed </h3>".$_SESSION['count'];
    ?>
</body>
</html>
