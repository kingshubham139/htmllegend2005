as4sa2.php
<?php
$name = $_POST['name'];
if(empty($name))
{
echo "Stranger, please tell me your name!";
}
elseif($name == 'Rohit' || $name == 'Virat' || $name == 'Dhoni' || $name ==
'Ashwin' || $name == 'Harbhajan')
{
echo "Hello, master $name!";
}
else
{
echo "$name, I don't know you.";
}
?>
