<?php

echo "<table border=1><tr><th>Details</th><th>values</th></tr>";

echo"<tr><td>Basic</td><td>".$_POST['t4']."</td></tr>";
echo"<tr><td>HRA</td><td>".$_POST['t5']."</td></tr>";
echo"<tr><td>DA</td><td>".$_POST['t6']."</td></tr></table>";

echo"<br><br>";

$total=$_POST['t4']+$_POST['t5']+$_POST['t6'];
echo "<br>Total:  ".$total;
?>




