<?php
session_start();
$un=$_POST["uname"]
$pw=$_POST["pass"]

if($un=="gauri" && $pw=="gauri34")
{
echo "WELCOME".$un;
}
else
{
if($_SESSION['cnt']==3)
{
echo "you lost chanced";
$_SESSION['cnt']=0;
}
else if($cnt<3)
{
echo "you have chanced".$_SESSION['cnt'];
$_SESSION['cnt']=$_SESSION['cnt']+1;
}
}
?>
