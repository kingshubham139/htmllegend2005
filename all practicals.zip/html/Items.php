<?php
$dom= new DomDocument();
$dom->load("Items.xml");
echo "<h2>name of item</h2>
$name=$dom->getElementsByTagName("name");
foreach($name as $n)
{
echo"<b>$n->textContents<b><br><br>";
}
?>

