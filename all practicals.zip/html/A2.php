<?php
echo "Style is".$_GET['s1']."<br>color is".$_GET['c']."<br>Background Coloris".$_GET['b']."<br>size is".$_GET['s'];

setcookie("set1",$_GET['s1'],time()+3600);
setcookie("set2",$_GET['c'],time()+3600);
setcookie("set3",$_GET['b'],time()+3600);
setcookie("set4",$_GET['s'],time()+3600);    
?>

<html>
<body>
<form action="A3.php" method="get">
<input type="submit"  value="Ok">
</form>
</body>
</html>
