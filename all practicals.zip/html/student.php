<?php
// Function with optional/default parameters
function generateGreeting($student = "Student", $college = "your college", $message = "Welcome!") {
    echo "<h3>$message $student from $college.</h3>";
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Initialize variables
    if (!empty($_POST['student_name'])) {
        $student = $_POST['student_name'];
    } else {
        $student = null;
    }

    if (!empty($_POST['college_name'])) {
        $college = $_POST['college_name'];
    } else {
        $college = null;
    }

    if (!empty($_POST['greeting_msg'])) {
        $message = $_POST['greeting_msg'];
    } else {
        $message = null;
    }

    // Call the function with parameters (they may be null)
    generateGreeting($student, $college, $message);
} else {
    echo "<h3>No data submitted.</h3>";
}
?>

