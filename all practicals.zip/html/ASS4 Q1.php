<!DOCTYPE html>
<html>
<head>
    <title>Spring Month Temperatures</title>
</head>
<body>
    <h2>Spring Month High Temperatures</h2>

    <?php
    // 30 high temperatures for a spring month (°C)
    $temps = [28, 30, 27, 25, 29, 31, 32, 26, 28, 30,
              27, 29, 33, 34, 32, 28, 29, 30, 26, 25,
              31, 33, 29, 30, 28, 27, 26, 32, 34, 33];

    // Calculate average
    $average = array_sum($temps) / count($temps);

    // Sort temperatures
    sort($temps); // ascending order
    $coolest = array_slice($temps, 0, 5);   // first 5 values
    $warmest = array_slice($temps, -5, 5);  // last 5 values

    // Display
    echo "<b>Average High Temperature:</b> " . round($average, 2) . " &deg;C<br><br>";

    echo "<b>Five Coolest High Temperatures:</b><br>";
    foreach ($coolest as $c) {
        echo $c . " &deg;C<br>";
    }

    echo "<br><b>Five Warmest High Temperatures:</b><br>";
    foreach ($warmest as $w) {
        echo $w . " &deg;C<br>";
    }
    ?>
</body>
</html>

