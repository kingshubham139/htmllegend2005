<!DOCTYPE html>
<html>
<head>
    <title>Email Validation using Regular Expressions</title>
</head>
<body>
    <h2>Email Validation</h2>
    <form method="post">
        Enter Email: <br>
        <input type="text" name="email" required>
        <br><br>
        <input type="submit" name="check" value="Validate">
    </form>
</body>
</html>

<?php
if (isset($_POST['check'])) {
    $email = $_POST['email'];
    echo "<h3>Entered Email: $email</h3>";

    // (a) Check that @ appears only once
    if (substr_count($email, "@") != 1) {
        echo "Invalid: The @ symbol should appear exactly once.<br>";
        exit;
    }

    // Split into parts
    $parts = explode("@", $email);
    $before = $parts[0];   // local part
    $after  = $parts[1];   // domain part

    // (b) Dot conditions
    $dotBefore = substr_count($before, ".");
    $dotAfter  = substr_count($after, ".");

    if ($dotBefore > 1) {
      echo "Invalid: Dot(.)can appear at most once befor@.<br>";
        exit;
    }
    if ($dotAfter < 1 || $dotAfter > 2) {
        echo " Invalid: Dot(.)must appear at least once and at most twice after @.<br>";
        exit;
    }

    // (c) First character rules
    // Should not begin with digit, underscore, dot, @, or special character
    if (ereg("^[0-9._@]", $before)) {
        echo "Invalid: Local part before @ should not begin with digit, underscore, dot, @, or special character.<br>";
        exit;
    }

    // General pattern check (alphanumeric, underscore, dot allowed)
    if (!ereg("^[A-Za-z0-9._-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$", $email)) {
        echo "Invalid: Does not match general email pattern.<br>";
        exit;
    }

    echo "Valid Email!";
}
?>

