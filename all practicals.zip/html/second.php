<html>
<body>
<?php 
$_COOKIE['$name'] = $_POST["name"];
setCookie('$ph-no'.$_POST["ph-no"]);
setCookie('$address'.$_POST["address"]);
echo "hello   "  .$_POST["name"]."enter details<br>";
?>

<form method="post" action="third1.php">
<table border="1">
<tr><td>Product Name</td><td><input type="text" name="pname"></td></tr>

<tr><td>quntity</td><td><input type="text" 
name="qty"></td></tr>

<tr><td>rate</td><td><input type="text" 
name="rate"></td></tr>

<tr><td></td><td><input type="submit" name="submit" value="display"></td></tr>
</table>
</form>
</body>
</html>





