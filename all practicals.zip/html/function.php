<?php
    $num1=$_REQUEST['num1'];
    $num2=$_REQUEST['num2'];
    $mod=$_REQUEST['mod'];                    
    $power=$_REQUEST['power'];
    $sum=$_REQUEST['sum'];
    $fact=$_REQUEST['fact'];

    function mod($num1,$num2)
    {
        $m=$num1 % $num2;
        echo $m;
    }
    function power($num1,$num2)
    {
        $p=$num1**$num2;
        echo $p;
    }
    function sum($num1)
    {
        $s=0;
        for($i=1;$i<=$num1;$i++)
        {
            $s=$s+$i;
        }
        echo $s;
    }
    function fact($num2)
    {
        $f=1;
        for($i=1;$i<=$num2;$i++)
        {
            $f=$f*$i;
        }
        echo $f;
    }
    if($mod=='mod')
    {
        mod($num1,$num2);
    }
    if($power=='power')
    {
        power($num1,$num2);
    }
    if($sum=='sum')
    {
        sum($num1);
    }
    if($fact=='fact')
    {
        fact($num2);
    }
?>

















