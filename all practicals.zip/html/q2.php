<?php
// a) Length of string without built-in function
function myStrLen($str) {
    $count = 0;
    while (isset($str[$count])) {
        $count++;
    }
    return $count;
}

// b) Count vowels
function countVowels($str) {
    $count = 0;
    $str = strtolower($str);
    $vowels = ['a', 'e', 'i', 'o', 'u'];
    for ($i = 0; $i < myStrLen($str); $i++) {
        if (in_array($str[$i], $vowels)) {
            $count++;
        }
    }
    return $count;
}

// c) Convert to lowercase then Title Case
function lowerToTitle($str) {
    $str = strtolower($str);
    return ucwords($str);
}

// d) Pad with '*'
function padWithStars($str) {
    return str_pad($str, myStrLen($str) + 4, "*", STR_PAD_BOTH);
}

// e) Remove leading whitespaces
function removeLeadingSpaces($str) {
    return ltrim($str);
}

// f) Reverse string
function reverseString($str) {
    return strrev($str);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>String Operations in PHP</title>
</head>
<body>

<h2>String Operations</h2>
<form method="post">
    Enter a String: <input type="text" name="myString" required><br><br>

    <input type="radio" name="operation" value="length" required> Find String Length (no built-in)<br>
    <input type="radio" name="operation" value="vowels"> Count Vowels<br>
    <input type="radio" name="operation" value="titlecase"> Lowercase → Title Case<br>
    <input type="radio" name="operation" value="pad"> Pad with '*' on both sides<br>
    <input type="radio" name="operation" value="trim"> Remove Leading Whitespaces<br>
    <input type="radio" name="operation" value="reverse"> Reverse String<br><br>

    <input type="submit" name="submit" value="Perform Operation">
</form>

<?php

if (isset($_POST['submit'])) {
    $str = $_POST['myString'];
    $op = $_POST['operation'];

    echo "<h3>Result:</h3>";

    switch ($op) {
        case 'length':
            echo "Length of string: " . myStrLen($str);
            break;
        case 'vowels':
            echo "Total vowels: " . countVowels($str);
            break;
        case 'titlecase':
            echo "Lowercase → Title Case: " . lowerToTitle($str);
            break;
        case 'pad':
            echo "Padded String: " . padWithStars($str);
            break;
        case 'trim':
            echo "After removing leading spaces: '" . removeLeadingSpaces($str) . "'";
            break;
        case 'reverse':
            echo "Reversed String: " . reverseString($str);
            break;
        default:
            echo "Invalid Option.";
    }
}
?>

</body>
</html>

