
<?php
$stack = array();
$queue = array();

while (true) {
    echo "\n===== MENU =====\n";
    echo "1. Insert into Stack\n";
    echo "2. Delete from Stack\n";
    echo "3. Display Stack\n";
    echo "4. Insert into Queue\n";
    echo "5. Delete from Queue\n";
    echo "6. Display Queue\n";
    echo "7. Exit\n";
    echo "Enter your choice: ";
    $choice = trim(fgets(STDIN));

    switch ($choice) {
        case 1:
            echo "Enter element to push into stack: ";
            $element = trim(fgets(STDIN));
            array_push($stack, $element); // insert at top
            echo "$element inserted into stack\n";
            break;

        case 2:
            if (!empty($stack)) {
                $deleted = array_pop($stack); // remove from top
                echo "$deleted deleted from stack\n";
            } else {
                echo "Stack is empty!\n";
            }
            break;

        case 3:
            if (!empty($stack)) {
                echo "Stack contents (Top → Bottom): ";
                print_r(array_reverse($stack)); // show in stack order
            } else {
                echo "Stack is empty!\n";
            }
            break;

        case 4:
            echo "Enter element to insert into queue: ";
            $element = trim(fgets(STDIN));
            array_push($queue, $element); // insert at end
            echo "$element inserted into queue\n";
            break;

        case 5:
            if (!empty($queue)) {
                $deleted = array_shift($queue); // remove from front
                echo "$deleted deleted from queue\n";
            } else {
                echo "Queue is empty!\n";
            }
            break;

        case 6:
            if (!empty($queue)) {
                echo "Queue contents (Front → Rear): ";
                print_r($queue);
            } else {
                echo "Queue is empty!\n";
            }
            break;

        case 7:
            echo "Exiting program...\n";
            exit;

        default:
            echo "Invalid choice! Please try again.\n";
    }
}
?>

