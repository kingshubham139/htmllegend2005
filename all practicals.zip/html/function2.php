<?php
$str=$_REQUEST['string'];
$ch=$_REQUEST['op'];

switch($ch){
    case 'strlen':
        $arr=str_split($str);
        echo "length of given string is: ".sizeof($arr);
        break;
    case 'vowels':
        $arr=str_split($str);
        $count=0;
        for($i=0;$i<sizeof($arr);$i++)
        {
            if($arr[$i]=='A' || $arr[$i]=='E' || $arr[$i]=='I' || $arr[$i]=='O' || $arr[$i]=='U'||
            $arr[$i]=='a' || $arr[$i]=='e' || $arr[$i]=='i' || $arr[$i]=='o' || $arr[$i]=='u')
            {
                $count++;
            }
        }
        echo $count;
        break;
    case 'lower':
        echo "String in title case: ".ucwords($str)."<br>";
        echo "String in Lower Case: ".strtolower($str);
        break;
    case 'pad_*':
        echo "String pad with *: ".str_pad($str,20,'*',STR_PAD_BOTH);
        break;
    case 'remwh':
        echo "Removing white space for given string: ".trim($str);
        break;
    case 'rev':
        echo "Reverse String: ".strrev($str);
        break;
    default:
        echo "Something is wrong!!!!!!".'&#128546';
        break;
}








?>
