<!DOCTYPE html>
<html>
<head>
    <title>String Operation Results</title>
</head>
<body>
    <h2>Results</h2>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $small = $_POST['small_string'];
    $large = $_POST['large_string'];
     $n = intval($_POST['n']);

// a. Check if small string appears at the start of the large string
    if (stripos($large, $small) === 0) 
    {
        echo "<p><strong>a.</strong> The small string '$small' appears at the start of the large string.</p>";
    } 
    else 
    {
        echo "<p><strong>a.</strong> The small string '$small' does NOT appear at the start of the large string.</p>";
    }
      

// b. Find position of small string in the large string
    $pos = stripos($large, $small); 
    if ($pos == true) 
    {
        echo "<p><strong>b.</strong> The small string is found at position <strong>$pos</strong> in the large string .</p>";
    } 
    else 
    {
        echo "<p><strong>b.</strong> The small string was not found in the large string.</p>";
    }
     

    // c. Compare first n characters of both strings 
    $small_sub = substr($small, 0, $n);
    $large_sub = substr($large, 0, $n);

    if (strcasecmp($small_sub, $large_sub) === 0) 
    {
        echo "<p><strong>c.</strong> The first $n characters of both strings are <strong>equal</strong> .</p>";
    } 
    else 
    {
        echo "<p><strong>c.</strong> The first $n characters of both strings are <strong>not equal</strong> .</p>";
    }
} 
else 
{
    echo "<p>No data submitted.</p>";
}
?>
<br><br>
<a href="form.html">Back to Form</a>
</body>
</html>













