<?php
// Original array
$arr = array(10, 20, 30, 40, 50);

echo "Original Array:\n";
print_r($arr);

$newItem = 50;
$position = 3; 


array_splice($arr, $position, 0, $newItem);

echo "\nArray after inserting $newItem at position $position:\n";
print_r($arr);
?>

