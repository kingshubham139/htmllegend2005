<?php
// read_contacts.php

// Path to the contact.dat file
$file = 'contact.dat';

// Check if file exists
if (file_exists($file)) {
    $lines = file($file, FILE_IGNORE_NEW_LINES); // Read file line by line
    $contacts = [];

    foreach ($lines as $line) {
        $data = explode(',', $line);  // Split the line by commas
        if (count($data) == 5) {
            $contacts[] = [
                'srno' => trim($data[0]),
                'name' => trim($data[1]),
                'residence_number' => trim($data[2]),
                'mobile_number' => trim($data[3]),
                'address' => trim($data[4])
            ];
        }
    }
    echo json_encode($contacts); // Return data as JSON
} else {
    echo json_encode(['error' => 'File not found']);
}
?>

