<?php
  setcookie('no',$_POST['t1']);
  setcookie('name',$_POST['t2']);
  setcookie('address',$_POST['t3']);
  ?>
  
  <html>
  <form action="display.php" method="post">
  <br>
  enter the earing:<br><br>
  basic salary :<input type="text" name="t4" size=3>
  <br><br>
  HRA :<input type="text" name="t5" size=3>
  <br><br>
  DA:<input type="text" name="t6" size=3>
  <br><br>
  <input type="submit" value="Display">
  </form>
  </html>
