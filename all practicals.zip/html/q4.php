<!DOCTYPE html>
<html>
<head>
    <title>String Separator Form</title>
</head>
<body>

<h2>String Separator Form</h2>

<form method="post">
    Enter your string:<br>
    <input type="text" name="input_string" required><br><br>

    Choose a separator:<br>
    <select name="separator" required>
        <option value="#">#</option>
        <option value="|">|</option>
        <option value="@">@</option>
    </select><br><br>

    Enter a new separator for replacement:<br>
    <input type="text" name="new_separator" required><br><br>

    <input type="submit" name="submit" value="Process">
</form>

<?php
function strrstr_custom($haystack, $needle, $before_needle = false) {
    $pos = strrpos($haystack, $needle);
    if ($pos === false) return false;
    return $before_needle ? substr($haystack, 0, $pos) : substr($haystack, $pos);
}

if (isset($_POST['submit'])) {
    $input_string = $_POST['input_string'];
    $separator = $_POST['separator'];
    $new_separator = $_POST['new_separator'];

    echo "<h3>Results:</h3>";

    // a. Split the string
    $words = explode($separator, $input_string);
    echo "Split words:<br>";
    foreach ($words as $word) {
        echo htmlspecialchars($word) . "<br>";
    }

    // b. Replace all occurrences
    $replaced_string = str_replace($separator, $new_separator, $input_string);
    echo "<br>String after replacing '$separator' with '$new_separator':<br>";
    echo htmlspecialchars($replaced_string) . "<br>";

    // c. Find the last word using simulated strrstr
    $last_part = strrstr_custom($input_string, $separator);
    $last_word = $last_part !== false ? substr($last_part, strlen($separator)) : $input_string;
    echo "<br>Last word in the string:<br>";
    echo htmlspecialchars($last_word);
}
?>                          

</body>
</html>










