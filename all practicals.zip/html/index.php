<!DOCTYPE html>
<html>
<head>
<title>practical exam</title>
</head>
<body>
<?php
$arr=array("Sagar"=>"31","Vicky"=>"41","Leena"=>"39","Ramesh"=>"40");
echo "Original Array:<br>";
print_r($arr);
echo "<br>";
//a) Ascending order sort by value
asort($arr);
echo "Ascending order by value:";
print_r($arr);
echo "<br>";
$arr=array("Sagar"=>"31","Vicky"=>"41","Leena"=>"39","Ramesh"=>"40");
//b)sort by key
ksort($arr);
echo "Ascending order by key:";
print_r($arr);
echo "<br>";
$arr=array("Sagar"=>"31","Vicky"=>"41","Leena"=>"39","Ramesh"=>"40");
//c) Descending order sort by value
arsort($arr);
echo "Descending order Array by value:";
print_r($arr);
echo "<br>";
$arr=array("Sagar"=>"31","Vicky"=>"41","Leena"=>"39","Ramesh"=>"40");
//d)sort by key
krsort($arr);
echo "Descending order Array by key:";
print_r($arr);
echo "<br>";
?>
</body>
</html>
