<!DOCTYPE html>
<html>
<head>
    <title>Student Marks Result</title>
</head>
<body>
    <h2>Enter Marks of 5 Subjects</h2>
    <form method="post">
        <table border="1" cellpadding="5">
            <tr>
                <th>Serial No.</th>
                <th>Subject Name</th>
                <th>Marks (out of 100)</th>
            </tr>
            <?php
            // Generate 5 rows with array-based inputs
            for ($i = 1; $i <= 5; $i++) {
                echo "<tr>";
                echo "<td><input type='text' name='serial[]' value='$i' readonly></td>";
                echo "<td><input type='text' name='subject[]'></td>";
                echo "<td><input type='text' name='marks[]'></td>";
                echo "</tr>";
            }
            ?>
        </table><br>
        <input type="submit" name="submit" value="Generate Result">
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $serials = $_POST['serial'];
        $subjects = $_POST['subject'];
        $marks = $_POST['marks'];

        $total = 0;

        echo "<h3>Result Table</h3>";
        echo "<table border='1' cellpadding='5'>
                <tr>
                    <th>Serial No.</th>
                    <th>Subject Name</th>
                    <th>Marks</th>
                </tr>";

        for ($i = 0; $i < count($subjects); $i++) {
            $m = (int)$marks[$i];
            $total += $m;

            echo "<tr>
                    <td>{$serials[$i]}</td>
                    <td>{$subjects[$i]}</td>
                    <td>{$marks[$i]}</td>
                  </tr>";
        }
        echo "</table>";

        // Calculate percentage
        $percentage = $total / 5;

        // Determine grade
        if ($percentage >= 90) {
            $grade = "A+";
        } elseif ($percentage >= 75) {
            $grade = "A";
        } elseif ($percentage >= 60) {
            $grade = "B";
        } elseif ($percentage >= 40) {
            $grade = "C";
        } else {
            $grade = "Fail";
        }

        echo "<h3>Total Marks: $total</h3>";
        echo "<h3>Percentage: $percentage%</h3>";
        echo "<h3>Grade: $grade</h3>";
    }
    ?>
</body>
</html>




