/*Implement the C program that accepts an integer array. Main function forks child 
process. Parent process sorts an integer array and passes the sorted array to child process 
through the command line arguments of execve() system call. The child process uses 
execve() system call to load new program that uses this sorted array for performing the 
binary search to search the particular item in the array*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

// Bubble sort function
void bubbleSort(int arr[], int n) {
    int i, j, temp;
    for(i=0; i<n-1; i++) {
        for(j=0; j<n-i-1; j++) {
            if(arr[j] > arr[j+1]) {
                temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
}

int main() {
    int n;
    printf("Enter number of elements: ");
    scanf("%d", &n);

    int arr[n];
    printf("Enter %d integers:\n", n);
    for(int i=0; i<n; i++) {
        scanf("%d", &arr[i]);
    }

    int key;
    printf("Enter the number to search: ");
    scanf("%d", &key);

    // Sort array
    bubbleSort(arr, n);

    pid_t pid = fork();

    if(pid < 0) {
        perror("fork failed");
        exit(1);
    }
    else if(pid == 0) {
        // Child process: execve new program (child_search)

        // Prepare args for execve:
        // argv[0] = "./child_search"
        // argv[1] = number of elements (as string)
        // argv[2..n+1] = sorted array elements (as strings)
        // argv[n+2] = key (as string)
        // argv[n+3] = NULL

        char **args = malloc((n + 4) * sizeof(char *));
        if(!args) {
            perror("malloc failed");
            exit(1);
        }

        args[0] = "./child_search";

        char buffer[20];

        // n as string
        snprintf(buffer, sizeof(buffer), "%d", n);
        args[1] = strdup(buffer);

        // sorted array elements as strings
        for(int i=0; i<n; i++) {
            snprintf(buffer, sizeof(buffer), "%d", arr[i]);
            args[i+2] = strdup(buffer);
        }

        // key as string
        snprintf(buffer, sizeof(buffer), "%d", key);
        args[n+2] = strdup(buffer);

        args[n+3] = NULL;

        execve("./child_search", args, NULL);

        perror("execve failed");
        exit(1);
    }
    else {
        // Parent waits for child to finish
        wait(NULL);
    }

    return 0;
}

