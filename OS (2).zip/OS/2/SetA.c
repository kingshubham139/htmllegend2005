/*Write a C program that behaves like a shell which displays the command prompt ‘myshell$’. It 
accepts the command, tokenize the command line and execute it by creating the child process. 
Also implement the additional command ‘count’ as 
myshell$ count c filename: It will display the number of characters in given file 
myshell$ count w filename: It will display the number of words in given file 
myshell$ count l filename: It will display the number of lines in given file */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_LINE 1024
#define MAX_ARGS 100

void tokenize(char *line, char **args, int *argc) {
    *argc = 0;
    char *token = strtok(line, " \t\n");
    while (token != NULL && *argc < MAX_ARGS - 1) {
        args[(*argc)++] = token;
        token = strtok(NULL, " \t\n");
    }
    args[*argc] = NULL;
}

void count_chars(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("fopen");
        return;
    }
    int ccount = 0;
    int ch;
    while ((ch = fgetc(fp)) != EOF) {
        ccount++;
    }
    fclose(fp);
    printf("Characters: %d\n", ccount);
}

void count_words(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("fopen");
        return;
    }
    int wcount = 0;
    int in_word = 0;
    int ch;
    while ((ch = fgetc(fp)) != EOF) {
        if (ch == ' ' || ch == '\n' || ch == '\t') {
            in_word = 0;
        } else if (!in_word) {
            in_word = 1;
            wcount++;
        }
    }
    fclose(fp);
    printf("Words: %d\n", wcount);
}

void count_lines(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("fopen");
        return;
    }
    int lcount = 0;
    int ch;
    while ((ch = fgetc(fp)) != EOF) {
        if (ch == '\n') lcount++;
    }
    fclose(fp);
    printf("Lines: %d\n", lcount);
}

int main() {
    char line[MAX_LINE];
    char *args[MAX_ARGS];
    int argc;

    while (1) {
        printf("myshell$ ");
        if (!fgets(line, sizeof(line), stdin)) {
            // EOF (Ctrl+D)
            printf("\n");
            break;
        }

        // Remove trailing newline if any
        line[strcspn(line, "\n")] = 0;

        // Skip empty lines
        if (strlen(line) == 0) continue;

        tokenize(line, args, &argc);

        if (argc == 0) continue;

        // Exit shell command
        if (strcmp(args[0], "exit") == 0) {
            break;
        }

        // Implement count command
        if (strcmp(args[0], "count") == 0) {
            if (argc != 3) {
                fprintf(stderr, "Usage: count [c|w|l] filename\n");
                continue;
            }
            char mode = args[1][0];
            const char *filename = args[2];

            if (mode == 'c') {
                count_chars(filename);
            } else if (mode == 'w') {
                count_words(filename);
            } else if (mode == 'l') {
                count_lines(filename);
            } else {
                fprintf(stderr, "Unknown mode '%c'. Use c, w, or l.\n", mode);
            }
            continue;
        }

        // For other commands, fork and exec
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            continue;
        }
        if (pid == 0) {
            // Child process
            execvp(args[0], args);
            // If execvp returns, error occurred
            perror("execvp");
            exit(EXIT_FAILURE);
        } else {
            // Parent process waits
            wait(NULL);
        }
    }

    return 0;
}

