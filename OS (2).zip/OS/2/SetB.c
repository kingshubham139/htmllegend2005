/*Write a C program that behaves like a shell which displays the command prompt ‘myshell$’. It 
accepts the command, tokenize the command line and execute it by creating the child process. 
Also implement the additional command ‘list’ as 
myshell$ list f dirname: It will display filenames in a given directory. 
myshell$ list n dirname: It will count the number of entries in a given directory. 
myshell$ list i dirname: It will display filenames and their inode number for the files in a given 
directory. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <dirent.h>

#define MAX_LINE 1024
#define MAX_ARGS 100

void tokenize(char *line, char **args, int *argc) {
    *argc = 0;
    char *token = strtok(line, " \t\n");
    while (token != NULL && *argc < MAX_ARGS - 1) {
        args[(*argc)++] = token;
        token = strtok(NULL, " \t\n");
    }
    args[*argc] = NULL;
}

void list_f(const char *dirname) {
    DIR *dir = opendir(dirname);
    if (!dir) {
        perror("opendir");
        return;
    }
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        // Skip "." and ".."
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) 
            continue;
        printf("%s\n", entry->d_name);
    }
    closedir(dir);
}

void list_n(const char *dirname) {
    DIR *dir = opendir(dirname);
    if (!dir) {
        perror("opendir");
        return;
    }
    int count = 0;
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        // Skip "." and ".."
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) 
            continue;
        count++;
    }
    closedir(dir);
    printf("Number of entries: %d\n", count);
}

void list_i(const char *dirname) {
    DIR *dir = opendir(dirname);
    if (!dir) {
        perror("opendir");
        return;
    }
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        // Skip "." and ".."
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) 
            continue;
        printf("%lu %s\n", (unsigned long)entry->d_ino, entry->d_name);
    }
    closedir(dir);
}

int main() {
    char line[MAX_LINE];
    char *args[MAX_ARGS];
    int argc;

    while (1) {
        printf("myshell$ ");
        if (!fgets(line, sizeof(line), stdin)) {
            printf("\n");
            break;  // EOF
        }

        // Remove trailing newline
        line[strcspn(line, "\n")] = 0;

        if (strlen(line) == 0) continue;

        tokenize(line, args, &argc);

        if (argc == 0) continue;

        if (strcmp(args[0], "exit") == 0) {
            break;
        }

        if (strcmp(args[0], "list") == 0) {
            if (argc != 3) {
                fprintf(stderr, "Usage: list [f|n|i] dirname\n");
                continue;
            }
            char mode = args[1][0];
            const char *dirname = args[2];

            if (mode == 'f') {
                list_f(dirname);
            } else if (mode == 'n') {
                list_n(dirname);
            } else if (mode == 'i') {
                list_i(dirname);
            } else {
                fprintf(stderr, "Unknown mode '%c'. Use f, n, or i.\n", mode);
            }
            continue;
        }

        // Execute other commands via child process
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            continue;
        }
        if (pid == 0) {
            execvp(args[0], args);
            perror("execvp");
            exit(EXIT_FAILURE);
        } else {
            wait(NULL);
        }
    }

    return 0;
}

