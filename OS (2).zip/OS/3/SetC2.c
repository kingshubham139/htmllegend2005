/*Write the program to simulate Round Robin (RR) scheduling. The arrival time and first 
CPU-burst for different n number of processes should be input to the algorithm. Also 
give the time quantum as input. Assume the fixed IO waiting time (2 units). The next 
CPU-burst should be generated randomly. The output should give Gantt chart, turnaround 
time and waiting time for each process. Also find the average waiting time and 
turnaround time.*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

#define MAX 100

typedef struct {
    int pid;
    int arrival_time;
    int cpu_burst1;
    int remaining_burst1;
    int cpu_burst2;
    int start_time1;
    int end_time1;
    int start_time2;
    int end_time2;
    int turnaround_time;
    int waiting_time;
    int completion_time;
    bool completed_first_burst;
    bool in_queue;
} Process;

typedef struct {
    int items[MAX];
    int front, rear;
} Queue;

void enqueue(Queue *q, int value) {
    if (q->rear < MAX - 1) {
        q->rear++;
        q->items[q->rear] = value;
    }
}

int dequeue(Queue *q) {
    if (q->front > q->rear)
        return -1;
    return q->items[q->front++];
}

bool isEmpty(Queue *q) {
    return q->front > q->rear;
}

int main() {
    Process p[MAX];
    int n, time_quantum;
    int current_time = 0;
    int completed = 0;
    const int io_wait = 2;
    float total_waiting = 0, total_turnaround = 0;
    int gantt[MAX * 100], gantt_size = 0;

    Queue q;
    q.front = 0;
    q.rear = -1;

    srand(time(0)); // for random burst2

    printf("Enter number of processes: ");
    scanf("%d", &n);
    printf("Enter time quantum: ");
    scanf("%d", &time_quantum);

    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter arrival time for Process P%d: ", i + 1);
        scanf("%d", &p[i].arrival_time);
        printf("Enter first CPU burst for Process P%d: ", i + 1);
        scanf("%d", &p[i].cpu_burst1);
        p[i].cpu_burst2 = rand() % 10 + 1;
        p[i].remaining_burst1 = p[i].cpu_burst1;
        p[i].completed_first_burst = false;
        p[i].in_queue = false;
    }

    // Add initially arrived processes to queue
    for (int i = 0; i < n; i++) {
        if (p[i].arrival_time == 0) {
            enqueue(&q, i);
            p[i].in_queue = true;
        }
    }

    while (completed < n) {
        if (!isEmpty(&q)) {
            int idx = dequeue(&q);
            p[idx].in_queue = false;

            if (p[idx].remaining_burst1 == p[idx].cpu_burst1)
                p[idx].start_time1 = (current_time > p[idx].arrival_time) ? current_time : p[idx].arrival_time;

            int exec_time = (p[idx].remaining_burst1 > time_quantum) ? time_quantum : p[idx].remaining_burst1;

            for (int i = 0; i < exec_time; i++) {
                gantt[gantt_size++] = p[idx].pid;
                current_time++;

                // Check for new arrivals
                for (int j = 0; j < n; j++) {
                    if (p[j].arrival_time <= current_time && !p[j].completed_first_burst && !p[j].in_queue && j != idx && p[j].remaining_burst1 > 0) {
                        enqueue(&q, j);
                        p[j].in_queue = true;
                    }
                }
            }

            p[idx].remaining_burst1 -= exec_time;

            if (p[idx].remaining_burst1 == 0) {
                p[idx].end_time1 = current_time;
                p[idx].completed_first_burst = true;
                completed++;
            } else {
                enqueue(&q, idx);
                p[idx].in_queue = true;
            }

        } else {
            gantt[gantt_size++] = -1;
            current_time++;

            for (int i = 0; i < n; i++) {
                if (p[i].arrival_time <= current_time && !p[i].completed_first_burst && !p[i].in_queue && p[i].remaining_burst1 > 0) {
                    enqueue(&q, i);
                    p[i].in_queue = true;
                }
            }
        }
    }

    // Second CPU burst (after IO wait) — FCFS
    for (int i = 0; i < n; i++) {
        p[i].start_time2 = p[i].end_time1 + io_wait;
        p[i].end_time2 = p[i].start_time2 + p[i].cpu_burst2;
        p[i].completion_time = p[i].end_time2;

        p[i].turnaround_time = p[i].completion_time - p[i].arrival_time;
        p[i].waiting_time = p[i].turnaround_time - (p[i].cpu_burst1 + p[i].cpu_burst2 + io_wait);

        total_turnaround += p[i].turnaround_time;
        total_waiting += p[i].waiting_time;
    }

    // Gantt Chart
    printf("\nGantt Chart:\n|");
    int prev = -2;
    for (int i = 0; i < gantt_size; i++) {
        if (gantt[i] != prev) {
            if (gantt[i] == -1)
                printf(" Idle ");
            else
                printf(" P%d ", gantt[i]);
        }
        prev = gantt[i];
    }
    printf("|\n0");
    prev = -2;
    for (int i = 1; i <= gantt_size; i++) {
        if (gantt[i] != prev) {
            printf("   %d", i);
        }
        prev = gantt[i];
    }

    // Results Table
    printf("\n\nProcess\tArr\tCPU1\tCPU2\tStart1\tEnd1\tStart2\tEnd2\tWT\tTAT\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n",
               p[i].pid,
               p[i].arrival_time,
               p[i].cpu_burst1,
               p[i].cpu_burst2,
               p[i].start_time1,
               p[i].end_time1,
               p[i].start_time2,
               p[i].end_time2,
               p[i].waiting_time,
               p[i].turnaround_time);
    }

    printf("\nAverage Waiting Time = %.2f\n", total_waiting / n);
    printf("Average Turnaround Time = %.2f\n", total_turnaround / n);

    return 0;
}

