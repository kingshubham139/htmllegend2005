/*Write the program to simulate Preemptive Priority scheduling. The arrival time and first 
CPU-burst and priority for different n number of processes should be input to the 
algorithm. Assume the fixed IO waiting time (2 units). The next CPU-burst should be 
generated randomly. The output should give Gantt chart, turnaround time and waiting 
time for each process. Also find the average waiting time and turnaround time.*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <time.h>

#define MAX 100

typedef struct {
    int pid;
    int arrival_time;
    int priority;
    int cpu_burst1;
    int remaining_time1;
    int cpu_burst2;
    int start_time1;
    int end_time1;
    int start_time2;
    int end_time2;
    int turnaround_time;
    int waiting_time;
    int completion_time;
    bool started;
    bool finished_first_burst;
} Process;

int findHighestPriority(Process p[], int n, int time) {
    int idx = -1;
    int min_priority = INT_MAX;

    for (int i = 0; i < n; i++) {
        if (!p[i].finished_first_burst && p[i].arrival_time <= time && p[i].remaining_time1 > 0) {
            if (p[i].priority < min_priority || 
               (p[i].priority == min_priority && p[i].arrival_time < p[idx].arrival_time)) {
                min_priority = p[i].priority;
                idx = i;
            }
        }
    }

    return idx;
}

int main() {
    Process p[MAX];
    int n;
    int current_time = 0;
    const int io_wait = 2;
    int completed = 0;
    int gantt[MAX * 50], gantt_size = 0;
    float total_waiting = 0, total_turnaround = 0;

    srand(time(0));

    printf("Enter number of processes: ");
    scanf("%d", &n);

    // Input process details
    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter arrival time for Process P%d: ", i + 1);
        scanf("%d", &p[i].arrival_time);
        printf("Enter first CPU burst for Process P%d: ", i + 1);
        scanf("%d", &p[i].cpu_burst1);
        printf("Enter priority for Process P%d (lower number = higher priority): ", i + 1);
        scanf("%d", &p[i].priority);

        p[i].remaining_time1 = p[i].cpu_burst1;
        p[i].cpu_burst2 = rand() % 10 + 1;
        p[i].started = false;
        p[i].finished_first_burst = false;
    }

    // First CPU burst scheduling: Preemptive Priority
    while (completed < n) {
        int idx = findHighestPriority(p, n, current_time);

        if (idx != -1) {
            if (!p[idx].started) {
                p[idx].start_time1 = current_time;
                p[idx].started = true;
            }

            gantt[gantt_size++] = p[idx].pid;
            p[idx].remaining_time1--;
            current_time++;

            if (p[idx].remaining_time1 == 0) {
                p[idx].end_time1 = current_time;
                p[idx].finished_first_burst = true;
                completed++;
            }
        } else {
            gantt[gantt_size++] = -1; // Idle
            current_time++;
        }
    }

    // Second CPU burst: FCFS after fixed I/O wait
    for (int i = 0; i < n; i++) {
        p[i].start_time2 = p[i].end_time1 + io_wait;
        p[i].end_time2 = p[i].start_time2 + p[i].cpu_burst2;
        p[i].completion_time = p[i].end_time2;

        // Calculate Turnaround & Waiting Time
        p[i].turnaround_time = p[i].completion_time - p[i].arrival_time;
        p[i].waiting_time = p[i].turnaround_time - (p[i].cpu_burst1 + p[i].cpu_burst2 + io_wait);

        total_turnaround += p[i].turnaround_time;
        total_waiting += p[i].waiting_time;
    }

    // Print Gantt Chart
    printf("\nGantt Chart:\n|");
    int prev = -2;
    for (int i = 0; i < gantt_size; i++) {
        if (gantt[i] != prev) {
            if (gantt[i] == -1)
                printf(" Idle ");
            else
                printf(" P%d ", gantt[i]);
        }
        prev = gantt[i];
    }
    printf("|\n0");
    prev = -2;
    for (int i = 1; i <= gantt_size; i++) {
        if (gantt[i] != prev) {
            printf("   %d", i);
        }
        prev = gantt[i];
    }

    // Print Table
    printf("\n\nProcess\tArr\tPri\tCPU1\tCPU2\tStart1\tEnd1\tStart2\tEnd2\tWT\tTAT\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n",
               p[i].pid,
               p[i].arrival_time,
               p[i].priority,
               p[i].cpu_burst1,
               p[i].cpu_burst2,
               p[i].start_time1,
               p[i].end_time1,
               p[i].start_time2,
               p[i].end_time2,
               p[i].waiting_time,
               p[i].turnaround_time);
    }

    // Averages
    printf("\nAverage Waiting Time = %.2f\n", total_waiting / n);
    printf("Average Turnaround Time = %.2f\n", total_turnaround / n);

    return 0;
}

