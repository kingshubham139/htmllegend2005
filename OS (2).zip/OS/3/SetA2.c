/*Write the program to simulate Non-preemptive Shortest Job First (SJF) -scheduling. The 
arrival time and first CPU-burst for different n number of processes should be input to the 
algorithm. Assume the fixed IO waiting time (2 units). The next CPU-burst should be 
generated randomly. The output should give Gantt chart, turnaround time and waiting 
time for each process. Also find the average waiting time and turnaround time.*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <time.h>

#define MAX 100

typedef struct {
    int pid;
    int arrival_time;
    int cpu_burst1;
    int cpu_burst2;
    int start_time1;
    int end_time1;
    int start_time2;
    int end_time2;
    int waiting_time;
    int turnaround_time;
    bool completed;
} Process;

void inputProcesses(Process p[], int n) {
    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter arrival time for Process P%d: ", i + 1);
        scanf("%d", &p[i].arrival_time);
        printf("Enter first CPU burst for Process P%d: ", i + 1);
        scanf("%d", &p[i].cpu_burst1);
        p[i].cpu_burst2 = rand() % 10 + 1; // second CPU burst (1 to 10)
        p[i].completed = false;
    }
}

int findNextProcess(Process p[], int n, int current_time) {
    int idx = -1;
    int min_burst = INT_MAX;

    for (int i = 0; i < n; i++) {
        if (!p[i].completed && p[i].arrival_time <= current_time) {
            if (p[i].cpu_burst1 < min_burst) {
                min_burst = p[i].cpu_burst1;
                idx = i;
            }
        }
    }

    return idx;
}

int main() {
    Process p[MAX];
    int n;
    const int io_wait = 2;
    float total_waiting_time = 0, total_turnaround_time = 0;

    srand(time(0)); // seed for random burst2

    printf("Enter number of processes: ");
    scanf("%d", &n);

    inputProcesses(p, n);

    int completed_count = 0;
    int current_time = 0;

    printf("\nGantt Chart:\n");

    // First CPU burst scheduling using Non-preemptive SJF
    while (completed_count < n) {
        int idx = findNextProcess(p, n, current_time);
        if (idx == -1) {
            current_time++;
            continue;
        }

        p[idx].start_time1 = current_time;
        p[idx].end_time1 = p[idx].start_time1 + p[idx].cpu_burst1;
        current_time = p[idx].end_time1;

        // Simulate I/O
        current_time += io_wait;

        // Start second CPU burst immediately after I/O
        p[idx].start_time2 = current_time;
        p[idx].end_time2 = p[idx].start_time2 + p[idx].cpu_burst2;
        current_time = p[idx].end_time2;

        // Turnaround and waiting time
        p[idx].turnaround_time = p[idx].end_time2 - p[idx].arrival_time;
        p[idx].waiting_time = p[idx].turnaround_time - (p[idx].cpu_burst1 + p[idx].cpu_burst2 + io_wait);

        p[idx].completed = true;
        completed_count++;

        // Print Gantt Chart entry
        printf("| P%d(%d-%d) IO(%d-%d) P%d(%d-%d) ",
               p[idx].pid, p[idx].start_time1, p[idx].end_time1,
               p[idx].end_time1, p[idx].start_time2,
               p[idx].pid, p[idx].start_time2, p[idx].end_time2);

        total_turnaround_time += p[idx].turnaround_time;
        total_waiting_time += p[idx].waiting_time;
    }

    printf("|\n");

    // Print results
    printf("\nProcess\tArrival\tCPU1\tCPU2\tWaiting\tTurnaround\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t%d\t%d\n", 
               p[i].pid, 
               p[i].arrival_time, 
               p[i].cpu_burst1, 
               p[i].cpu_burst2, 
               p[i].waiting_time, 
               p[i].turnaround_time);
    }

    printf("\nAverage Waiting Time = %.2f\n", total_waiting_time / n);
    printf("Average Turnaround Time = %.2f\n", total_turnaround_time / n);

    return 0;
}

