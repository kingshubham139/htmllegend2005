/*Write the program to simulate Non-preemptive Priority scheduling. The arrival time and 
first CPU-burst and priority for different n number of processes should be input to the 
algorithm. Assume the fixed IO waiting time (2 units). The next CPU-burst should be 
generated randomly. The output should give Gantt chart, turnaround time and waiting 
time for each process. Also find the average waiting time and turnaround time.*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <time.h>

#define MAX 100

typedef struct {
    int pid;
    int arrival_time;
    int cpu_burst1;
    int cpu_burst2;
    int priority;
    int start_time1;
    int end_time1;
    int start_time2;
    int end_time2;
    int turnaround_time;
    int waiting_time;
    bool completed;
} Process;

void inputProcesses(Process p[], int n) {
    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter arrival time for Process P%d: ", p[i].pid);
        scanf("%d", &p[i].arrival_time);
        printf("Enter first CPU burst time for Process P%d: ", p[i].pid);
        scanf("%d", &p[i].cpu_burst1);
        printf("Enter priority for Process P%d (lower value = higher priority): ", p[i].pid);
        scanf("%d", &p[i].priority);
        p[i].cpu_burst2 = rand() % 10 + 1; // Random second burst between 1 and 10
        p[i].completed = false;
    }
}

int findNextProcess(Process p[], int n, int current_time) {
    int min_priority = INT_MAX;
    int idx = -1;

    for (int i = 0; i < n; i++) {
        if (!p[i].completed && p[i].arrival_time <= current_time) {
            if (p[i].priority < min_priority) {
                min_priority = p[i].priority;
                idx = i;
            } else if (p[i].priority == min_priority) {
                // If priority tie, use earlier arrival
                if (p[i].arrival_time < p[idx].arrival_time) {
                    idx = i;
                }
            }
        }
    }

    return idx;
}

int main() {
    Process p[MAX];
    int n;
    const int io_time = 2;
    int current_time = 0, completed = 0;
    float total_waiting_time = 0, total_turnaround_time = 0;

    srand(time(0));

    printf("Enter number of processes: ");
    scanf("%d", &n);

    inputProcesses(p, n);

    printf("\nGantt Chart:\n");

    while (completed < n) {
        int idx = findNextProcess(p, n, current_time);

        if (idx == -1) {
            // CPU is idle
            current_time++;
            continue;
        }

        // First CPU burst
        if (current_time < p[idx].arrival_time)
            current_time = p[idx].arrival_time;

        p[idx].start_time1 = current_time;
        p[idx].end_time1 = p[idx].start_time1 + p[idx].cpu_burst1;
        current_time = p[idx].end_time1;

        printf("| P%d(%d-%d) ", p[idx].pid, p[idx].start_time1, p[idx].end_time1);

        // Simulate IO time
        current_time += io_time;

        // Second CPU burst
        p[idx].start_time2 = current_time;
        p[idx].end_time2 = p[idx].start_time2 + p[idx].cpu_burst2;
        current_time = p[idx].end_time2;

        // Completion, waiting, turnaround
        p[idx].turnaround_time = p[idx].end_time2 - p[idx].arrival_time;
        p[idx].waiting_time = p[idx].turnaround_time - (p[idx].cpu_burst1 + p[idx].cpu_burst2 + io_time);
        p[idx].completed = true;
        completed++;

        total_waiting_time += p[idx].waiting_time;
        total_turnaround_time += p[idx].turnaround_time;
    }
    printf("|\n");

    // Display table
    printf("\nProcess\tAT\tPriority\tCPU1\tCPU2\tWT\tTAT\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t\t%d\t%d\t%d\t%d\n",
               p[i].pid,
               p[i].arrival_time,
               p[i].priority,
               p[i].cpu_burst1,
               p[i].cpu_burst2,
               p[i].waiting_time,
               p[i].turnaround_time);
    }

    printf("\nAverage Waiting Time = %.2f\n", total_waiting_time / n);
    printf("Average Turnaround Time = %.2f\n", total_turnaround_time / n);

    return 0;
}

