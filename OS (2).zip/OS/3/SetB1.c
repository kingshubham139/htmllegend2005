/*Write the program to simulate Preemptive Shortest Job First (SJF) -scheduling. The 
arrival time and first CPU-burst for different n number of processes should be input to the 
algorithm. Assume the fixed IO waiting time (2 units). The next CPU-burst should be 
generated randomly. The output should give Gantt chart, turnaround time and waiting 
time for each process. Also find the average waiting time and turnaround time.*/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <limits.h>
#include <time.h>

#define MAX 100

typedef struct {
    int pid;
    int arrival_time;
    int cpu_burst1;
    int cpu_burst2;
    int remaining_time1;
    int start_time1;
    int end_time1;
    int start_time2;
    int end_time2;
    int waiting_time;
    int turnaround_time;
    int completion_time;
    bool first_start;
    bool done_first;
} Process;

void inputProcesses(Process p[], int n) {
    for (int i = 0; i < n; i++) {
        p[i].pid = i + 1;
        printf("Enter arrival time for Process P%d: ", i + 1);
        scanf("%d", &p[i].arrival_time);
        printf("Enter first CPU burst for Process P%d: ", i + 1);
        scanf("%d", &p[i].cpu_burst1);
        p[i].cpu_burst2 = rand() % 10 + 1; // 1-10 units
        p[i].remaining_time1 = p[i].cpu_burst1;
        p[i].first_start = false;
        p[i].done_first = false;
    }
}

int findShortestJob(Process p[], int n, int time) {
    int idx = -1;
    int min_time = INT_MAX;
    for (int i = 0; i < n; i++) {
        if (p[i].arrival_time <= time && !p[i].done_first && p[i].remaining_time1 > 0) {
            if (p[i].remaining_time1 < min_time) {
                min_time = p[i].remaining_time1;
                idx = i;
            }
        }
    }
    return idx;
}

int main() {
    Process p[MAX];
    int n;
    int completed = 0;
    int current_time = 0;
    const int io_wait = 2;
    float total_waiting_time = 0, total_turnaround_time = 0;

    srand(time(0));

    printf("Enter number of processes: ");
    scanf("%d", &n);

    inputProcesses(p, n);

    int gantt[MAX * 20], gantt_size = 0;

    // Preemptive SJF for first CPU burst
    while (completed < n) {
        int idx = findShortestJob(p, n, current_time);

        if (idx != -1) {
            if (!p[idx].first_start) {
                p[idx].start_time1 = current_time;
                p[idx].first_start = true;
            }

            gantt[gantt_size++] = p[idx].pid;

            p[idx].remaining_time1--;
            current_time++;

            if (p[idx].remaining_time1 == 0) {
                p[idx].end_time1 = current_time;
                p[idx].done_first = true;
                completed++;
            }
        } else {
            gantt[gantt_size++] = -1; // idle
            current_time++;
        }
    }

    // I/O and second CPU burst
    for (int i = 0; i < n; i++) {
        // simulate I/O wait
        p[i].start_time2 = p[i].end_time1 + io_wait;
        p[i].end_time2 = p[i].start_time2 + p[i].cpu_burst2;

        // Final completion time
        p[i].completion_time = p[i].end_time2;

        // Turnaround and waiting time
        p[i].turnaround_time = p[i].completion_time - p[i].arrival_time;
        p[i].waiting_time = p[i].turnaround_time - (p[i].cpu_burst1 + p[i].cpu_burst2 + io_wait);

        total_waiting_time += p[i].waiting_time;
        total_turnaround_time += p[i].turnaround_time;
    }

    // Gantt Chart
    printf("\nGantt Chart:\n");
    printf("|");
    for (int i = 0; i < gantt_size; i++) {
        if (i == 0 || gantt[i] != gantt[i - 1]) {
            if (gantt[i] == -1)
                printf(" Idle ");
            else
                printf(" P%d ", gantt[i]);
        }
    }
    printf("|\n");

    // Time Line
    int timeline = 0;
    printf("0");
    for (int i = 1; i < gantt_size; i++) {
        if (gantt[i] != gantt[i - 1]) {
            printf("   %d", i);
        }
    }
    printf("   %d\n", gantt_size);

    // Table
    printf("\nProcess\tArrival\tCPU1\tCPU2\tStart\tEnd1\tStart2\tEnd2\tWaiting\tTurnaround\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n",
               p[i].pid,
               p[i].arrival_time,
               p[i].cpu_burst1,
               p[i].cpu_burst2,
               p[i].start_time1,
               p[i].end_time1,
               p[i].start_time2,
               p[i].end_time2,
               p[i].waiting_time,
               p[i].turnaround_time);
    }

    printf("\nAverage Waiting Time = %.2f\n", total_waiting_time / n);
    printf("Average Turnaround Time = %.2f\n", total_turnaround_time / n);

    return 0;
}

